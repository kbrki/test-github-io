# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetConsumptionCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetconsumptionclod)

Das ValueSet enthält für Botulismus die Antwortmöglichkeiten für den Ort des Verzehrs. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetConsumptionCLOD}}
