# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/notificationDiseaseCategory](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/notificationdiseasecategory)    

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/notificationDiseaseCategory](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/notificationdiseasecategory).  

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/notificationDiseaseCategory}}