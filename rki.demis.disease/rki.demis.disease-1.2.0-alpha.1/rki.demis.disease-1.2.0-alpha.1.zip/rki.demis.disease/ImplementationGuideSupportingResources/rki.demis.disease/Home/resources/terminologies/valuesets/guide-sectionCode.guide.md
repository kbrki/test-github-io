# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/sectionCode](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/sectioncode) 

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/sectionCode](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/sectioncode).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/sectionCode}}