# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/evidenceGFVD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/evidencegfvd)

Das ValueSet enthält für Gelbfieber spezifische Symtome/Manfestationen der Erkrankung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/evidenceGFVD}}
