# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/translationNullFlavor](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/translationnullflavor) 

Das Codesystem ist ein Supplement zu http://terminology.hl7.org/CodeSystem/v3-NullFlavor und dient der Übersetzung relevanter Konzepte in die deutsche Sprache. Dies stellt eine Notwendigkeit im Zusammenhang mit der Anzeige entsprechender Konzepte im Meldeportal oder in anderen Nutzeroberflächen dar.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/translationNullFlavor}}
