# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/militaryAffiliation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/militaryaffiliation) 

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/militaryAffiliation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/militaryaffiliation).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/militaryAffiliation}}