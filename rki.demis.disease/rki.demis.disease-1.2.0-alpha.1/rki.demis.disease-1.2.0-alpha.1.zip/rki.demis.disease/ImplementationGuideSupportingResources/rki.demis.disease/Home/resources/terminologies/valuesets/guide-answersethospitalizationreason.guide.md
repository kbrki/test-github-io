# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/answerSetHospitalizationReason](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersethospitalizationreason) 

Enthält zusätzlich zu den Konzepte aus [https://demis.rki.de/fhir/CodeSystem/hospitalizationReason](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/hospitalizationreason) zwei Null-Flavors, um z.B. darauf hinweisen zu können, dass eine Information nicht erfragt wurde oder nicht ermittelbar ist.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetHospitalizationReason}}