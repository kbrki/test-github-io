# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineDEND_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinedend_snomed)

Das ValueSet enthält für Denguefieber spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineDEND_SNOMED}}
