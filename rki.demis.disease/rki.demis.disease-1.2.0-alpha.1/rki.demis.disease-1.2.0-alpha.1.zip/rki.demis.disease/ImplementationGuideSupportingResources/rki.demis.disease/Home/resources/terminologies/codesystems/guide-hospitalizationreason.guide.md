# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/hospitalizationReason](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/hospitalizationreason) 

Konzepte des CodeSystems beschreiben den Grund für die Hospitalisierung einer betroffenen Person.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/hospitalizationReason}}