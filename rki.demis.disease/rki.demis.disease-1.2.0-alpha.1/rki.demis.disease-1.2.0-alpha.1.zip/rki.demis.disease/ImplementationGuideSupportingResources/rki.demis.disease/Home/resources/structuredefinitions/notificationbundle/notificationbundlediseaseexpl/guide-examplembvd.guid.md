# {{page-title}}

{{xml:ExampleResources/example-bundle-notificationbundledisease-mbvd-01.xml}}
