# {{page-title}} 
[https://demis.rki.de/fhir/StructureDefinition/NotificationBundle](https://simplifier.net/demis/~resources?canonical=https://demis.rki.de/fhir/structuredefinition/notificationbundle&category=Profile&sortBy=RankScore_desc) 

Die Definition des **NotificationBundle**-Profils (Meldevorgang) erfolgt innerhalb des Implementierungsleitfadens für die DEMIS Erregernachweismeldung. Weiterführende Informationen zum Profil finden Sie unter der oben verlinkten Location. 
