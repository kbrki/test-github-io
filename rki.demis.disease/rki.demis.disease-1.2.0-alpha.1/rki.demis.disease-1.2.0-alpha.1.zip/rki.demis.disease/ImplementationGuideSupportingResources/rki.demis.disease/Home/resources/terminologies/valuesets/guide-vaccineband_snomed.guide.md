# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineBAND_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccineband_snomed)

Das ValueSet enthält für Milzbrand spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineBAND_SNOMED}}
