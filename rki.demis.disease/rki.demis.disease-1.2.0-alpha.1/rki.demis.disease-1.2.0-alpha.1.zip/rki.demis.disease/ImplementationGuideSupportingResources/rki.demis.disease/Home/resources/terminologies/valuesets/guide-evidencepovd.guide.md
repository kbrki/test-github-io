# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/evidencePOVD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/evidencepovd)

Das ValueSet enthält für Poliomyelitis spezifische Symtome/Manfestationen der Erkrankung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/evidencePOVD}}
