# {{page-title}}

## Erstmeldung
{{xml:ExampleResources/example-bundle-notificationbundledisease-hfad-01a.xml}}

## Ergänzungsmeldung
{{xml:ExampleResources/example-bundle-notificationbundledisease-hfad-01b.xml}}
