# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/evidenceMBVD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/evidencembvd)

Das ValueSet enthält für Marburgfieber spezifische Symtome/Manfestationen der Erkrankung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/evidenceMBVD}}
