# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineGFVD_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinegfvd_snomed)

Das ValueSet enthält für Gelbfieber spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineGFVD_SNOMED}}
