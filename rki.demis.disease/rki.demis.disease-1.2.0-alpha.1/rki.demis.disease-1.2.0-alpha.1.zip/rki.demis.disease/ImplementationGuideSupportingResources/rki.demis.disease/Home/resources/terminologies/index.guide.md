# {{page-title}}
Die folgenden Unterseiten geben einen Überblick über die im Rahmen der Erkrankungsmeldung genutzten Terminologien. Neben der initialen Darstellung von Codesystemen und Valuesets werden an dieser Stelle zukünftig auch Informationen zum Konzept-Mapping (ConceptMaps) zu finden sein. 
