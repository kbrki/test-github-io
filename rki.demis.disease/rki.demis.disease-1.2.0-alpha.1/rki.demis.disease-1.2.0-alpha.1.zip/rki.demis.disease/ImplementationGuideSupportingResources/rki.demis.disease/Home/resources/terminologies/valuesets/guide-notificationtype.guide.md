# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/notificationType](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/notificationtype) 

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/notificationType](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/notificationtype).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/notificationType}}