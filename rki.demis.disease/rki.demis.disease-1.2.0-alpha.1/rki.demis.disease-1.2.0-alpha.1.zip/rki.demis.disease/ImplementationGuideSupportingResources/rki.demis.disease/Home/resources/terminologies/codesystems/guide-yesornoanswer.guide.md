# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/yesOrNoAnswer](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/yesornoanswer) 

Die enthaltenen Elemente dieses CodeSystems bezeichnen die beiden Konzepte "ja" und "nein" und kommen bevorzugt als Antwortmöglichkeiten in den Fragebögen zum Einsatz.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/yesOrNoAnswer}}