# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/yesOrNoOrNoInformation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/yesornoornoinformation) 

Enthält zusätzlich zu den Konzepte aus [https://demis.rki.de/fhir/CodeSystem/yesOrNoAnswer](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/yesornoanswer) zwei Null-Flavors, um z.B. darauf hinweisen zu können, dass eine Information nicht erfragt wurde oder nicht ermittelbar ist.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/yesOrNoOrNoInformation}}