# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/hospitalizationReason](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/hospitalizationreason)    

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/hospitalizationReason](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/hospitalizationReason).  

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/hospitalizationReason}}