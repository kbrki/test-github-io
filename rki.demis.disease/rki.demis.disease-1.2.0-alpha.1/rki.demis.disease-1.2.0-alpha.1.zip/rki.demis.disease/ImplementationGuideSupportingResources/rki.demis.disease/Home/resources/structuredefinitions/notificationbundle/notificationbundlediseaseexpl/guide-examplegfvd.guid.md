# {{page-title}}

{{xml:ExampleResources/example-bundle-notificationbundledisease-gfvd-01.xml}}
