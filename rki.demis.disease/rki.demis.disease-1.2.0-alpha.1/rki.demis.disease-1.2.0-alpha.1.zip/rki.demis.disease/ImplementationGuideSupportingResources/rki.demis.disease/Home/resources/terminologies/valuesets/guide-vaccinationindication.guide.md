# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/vaccinationIndication](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinationindication) 

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/vaccinationIndication](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/vaccinationindication).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccinationIndication}}