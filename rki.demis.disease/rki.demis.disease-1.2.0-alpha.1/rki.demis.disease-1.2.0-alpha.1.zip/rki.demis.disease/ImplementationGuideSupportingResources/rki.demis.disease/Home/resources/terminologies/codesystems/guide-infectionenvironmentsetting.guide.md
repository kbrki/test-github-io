# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/infectionEnvironmentSetting](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/infectionenvironmentsetting) 

Die enthaltenen Konzepte beschreiben ein Infektionsumfeld. Dabei handelt es sich primär um qualitative Angaben zum Umfeld (z.B. Kita, Gesundheitseinrichtung) ohne einen genauen geografischen oder organisatorischen Bezug.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/infectionEnvironmentSetting}}