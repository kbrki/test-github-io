# {{page-title}}
Für der Erkrankungsmeldung werden zur Darstellung der Hospitalisierungsinformationen innerhalb der Encounter-Ressource zwei Extensions genutzt:

- HospitalizationRegion - Diese Erweiterung wird zur Darstellung der Region der Hospitalisierung genutzt. Diese Information ist insbesondere dann von Bedeutung, wenn kein konkretes Krankenhaus angegeben werden kann. Dies könnte beispielsweise bei Aufenthalten im Ausland der Fall sein.
- HospitalizationNote - Über diese Erweiterung kann die meldepflichtige Person weitere textuelle Hinweise zur Hospitalisierung gegenüber den empfangenden Gesundheitsämtern kommunizieren.

Weiterführende Informationen können den Unterseiten entnommen werden.