# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccinePOVD_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinepovd_snomed)

Das ValueSet enthält für Poliomyelitis spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccinePOVD_SNOMED}}
