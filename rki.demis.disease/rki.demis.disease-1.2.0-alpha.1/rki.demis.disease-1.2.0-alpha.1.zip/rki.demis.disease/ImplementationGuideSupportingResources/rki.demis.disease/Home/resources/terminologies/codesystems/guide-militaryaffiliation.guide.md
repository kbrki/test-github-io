# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/militaryAffiliation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/militaryaffiliation) 

Die in diesem CodeSystem enthaltenen Konzepte können genutzt werden, um den Bezug einer Person zur Bundeswehr zu beschreiben. Diese Information wird innerhalb des meldetatbestandsübergreifenden Fragebogens abgefragt und hat Einfluss auf die sich an die Meldung anschließende Fallbearbeitung durch das Gesundheitsamt und/oder Stellen der Bundeswehr.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/militaryAffiliation}}