# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetPathogenHFAD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetpathogenhfad)

Das ValueSet enthält für Hämorrhagisches Fieber spezifische Erreger. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetPathogenHFAD}}
