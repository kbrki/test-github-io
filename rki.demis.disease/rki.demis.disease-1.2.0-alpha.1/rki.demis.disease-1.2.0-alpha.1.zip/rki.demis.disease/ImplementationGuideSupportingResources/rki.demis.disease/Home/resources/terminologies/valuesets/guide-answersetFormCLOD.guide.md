# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetFormCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetformclod)

Das ValueSet enthält für Milzbrand spezifische Krankheitsformen. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetFormCLOD}}
