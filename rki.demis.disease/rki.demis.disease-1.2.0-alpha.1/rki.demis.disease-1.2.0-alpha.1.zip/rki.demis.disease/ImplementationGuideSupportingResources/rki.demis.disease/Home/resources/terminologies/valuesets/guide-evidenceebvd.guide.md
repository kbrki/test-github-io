# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/evidenceEBVD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/evidenceebvd)

Das ValueSet enthält für Ebolafieber spezifische Symtome/Manfestationen der Erkrankung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/evidenceEBVD}}
