# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetManufacturingCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetmanufacturingclod)

Das ValueSet enthält für Botulismus die Antwortmöglichkeiten für die Art der Lebensmittelherstellung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetManufacturingCLOD}}
