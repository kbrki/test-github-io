# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetConservationCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetconservationclod)

Das ValueSet enthält für Botulismus die Antwortmöglichkeiten für die Art der Lebensmittelkonservierung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetConservationCLOD}}
