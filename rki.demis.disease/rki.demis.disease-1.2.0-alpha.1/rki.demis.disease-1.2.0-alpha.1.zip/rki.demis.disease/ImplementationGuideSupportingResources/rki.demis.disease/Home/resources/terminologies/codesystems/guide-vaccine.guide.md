# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/vaccine](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/vaccine) 

Die enthaltenen Elemente dieses CodeSystems bezeichnen Impfstoffe, die sich ggf. nicht in anderen Listen (z.B. der EMA) wiederfinden

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/vaccine}}