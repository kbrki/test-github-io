# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineCORD_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinecord_snomed)

Das ValueSet enthält für Diphtherie spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineCORD_SNOMED}}
