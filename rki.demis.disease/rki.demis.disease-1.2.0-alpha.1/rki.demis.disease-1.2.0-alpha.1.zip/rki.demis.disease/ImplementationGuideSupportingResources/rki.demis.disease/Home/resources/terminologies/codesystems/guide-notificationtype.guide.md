# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/notificationType](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/notificationtype)  

Die enthaltene Konzepte repräsentieren grobe Typen/Arten von Meldungen (z.B. "Meldung gemäß §6 Absatz 1, 2 IfSG"). Sie werden genutzt um Meldungsarten voneinander unterscheiden zu können und eine auf die jeweilige Meldungsart zugeschnittene Verarbeitungslogik zu ermöglichen. 

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/notificationType}}