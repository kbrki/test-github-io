# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/vaccinationIndication](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/vaccinationindication) 

Die enthaltenen Elemente dieses CodeSystems bezeichnen die die von der STIKO unterschiedenen Konzepte zur Impfindikation.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/vaccinationIndication}}