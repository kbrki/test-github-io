# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/hospitalizationType](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/hospitalizationservicetype)    

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/hospitalizationServiceType](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/hospitalizationServiceType).  

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/hospitalizationServiceType}}