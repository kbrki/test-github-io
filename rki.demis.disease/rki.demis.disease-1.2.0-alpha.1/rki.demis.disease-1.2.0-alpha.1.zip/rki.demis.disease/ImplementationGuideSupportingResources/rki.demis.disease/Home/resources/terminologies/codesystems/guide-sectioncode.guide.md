# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/sectionCode](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/sectioncode)

Die im CodeSystem enthaltenen Konzepte beschreiben möglichen Abschnitte eines Dokuments (Composition). Über die Abschnittscodes ist es möglich zielgenau auf bestimmte Inhalte (z.B. einer Meldung) zuzugreifen.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/sectionCode}}