# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/nullFlavor](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/nullflavor)

Das ValueSet enthält die NullFlavors. Alle referenzierten Konzepte stammen aus dem [HL7-CodeSystem NullFlavor](https://www.hl7.org/fhir/v3/NullFlavor/cs.html).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/nullFlavor}}
