# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineBPSD_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinebpsd_snomed)

Das ValueSet enthält für Keuchusten spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineBPSD_SNOMED}}
