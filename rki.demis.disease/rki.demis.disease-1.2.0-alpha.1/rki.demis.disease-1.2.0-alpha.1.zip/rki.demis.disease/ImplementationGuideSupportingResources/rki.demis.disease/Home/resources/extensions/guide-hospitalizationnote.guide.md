# {{page-title}}
[https://demis.rki.de/fhir/StructureDefinition/HospitalizationNote](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/structuredefinition/hospitalizationnote)
 
Über diese Erweiterung kann die meldepflichtige Person weitere textuelle Hinweise zur Hospitalisierung gegenüber den empfangenden Gesundheitsämtern kommunizieren. Derzeit wird sie ausschließlich innerhalb der [Hospitalization](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/structuredefinition/hospitalization)-Ressource genutzt. 

**Profilansicht**
{{tree:https://demis.rki.de/fhir/StructureDefinition/HospitalizationNote, hybrid}}