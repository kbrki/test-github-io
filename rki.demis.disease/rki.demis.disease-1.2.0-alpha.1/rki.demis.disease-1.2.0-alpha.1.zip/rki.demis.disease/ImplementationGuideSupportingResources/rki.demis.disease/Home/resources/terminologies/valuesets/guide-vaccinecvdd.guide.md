# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/vaccineCVDD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinecvdd)    

Das ValueSet enthält für COVID-19 spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus der EMA-Liste für zugelassene Medizinalprodukte.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineCVDD}}