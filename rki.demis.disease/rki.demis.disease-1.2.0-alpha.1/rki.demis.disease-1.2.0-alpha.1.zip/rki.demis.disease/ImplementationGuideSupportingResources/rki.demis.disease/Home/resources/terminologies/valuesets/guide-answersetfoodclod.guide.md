# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetFoodCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetfoodclod)

Das ValueSet enthält für Botulismus die Antwortmöglichkeiten für die verzehrten Lebensmittel. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetFoodCLOD}}
