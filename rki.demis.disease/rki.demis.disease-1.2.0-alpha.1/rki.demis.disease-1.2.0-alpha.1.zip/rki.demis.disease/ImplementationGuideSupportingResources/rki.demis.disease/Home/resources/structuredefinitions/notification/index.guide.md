# {{page-title}} 
[https://demis.rki.de/fhir/StructureDefinition/Notification](https://simplifier.net/demis/~resources?canonical=https://demis.rki.de/fhir/structuredefinition/notification&category=Profile&sortBy=RankScore_desc)  

Die Definition des **Notification**-Profils (Meldung) erfolgt innerhalb des Implementierungsleitfadens für die DEMIS Erregernachweismeldung. Weiterführende Informationen zum Profil finden Sie unter der oben verlinkten Location. 
