# {{page-title}} 
[https://demis.rki.de/fhir/CodeSystem/organizationAssociation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/organizationassociation) 

Die in diesem CodeSystem enthaltenen Konzepte beschreiben die Beziehung, die eine Person zu einer bestimmten (Gemeinschafts-)Einrichtung haben kann. Es wird zwischen den sich aus dem IfSG ableitenden Beziehungsarten, die u.a. Auswirkungen auf die Meldepflichtigkeit eines Tatbestands haben, unterschieden.

**Inhalte**
{{render:https://demis.rki.de/fhir/CodeSystem/organizationAssociation}}