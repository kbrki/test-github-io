# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/vaccineCVDD_SNOMED](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/vaccinecvdd_snomed)    

Das ValueSet enthält für COVID-19 spezifischen Impfstoffe. Alle referenzierten Konzepte stammen aus SNOMED_CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/vaccineCVDD_SNOMED}}
