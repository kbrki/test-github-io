# {{page-title}}

{{xml:ExampleResources/example-bundle-notificationbundledisease-ebvd-01.xml}}
