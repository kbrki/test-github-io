# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/infectionEnvironmentSettingCVDD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/infectionenvironmentsetting)   

Enthält ausschließlich die für COVID-19 relevanten Konzepte aus [https://demis.rki.de/fhir/CodeSystem/infectionEnvironmentSetting](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/infectionenvironmentsetting).

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/infectionEnvironmentSettingCVDD}}