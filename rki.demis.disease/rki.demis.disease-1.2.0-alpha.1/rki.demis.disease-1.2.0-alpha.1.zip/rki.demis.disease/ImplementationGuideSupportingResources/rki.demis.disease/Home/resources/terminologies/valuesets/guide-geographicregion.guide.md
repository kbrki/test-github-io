# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/geographicRegion](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/geographicregion)   

Enthält alle Konzepte aus [https://demis.rki.de/fhir/CodeSystem/geographicRegion](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/geographicregion).  

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/geographicRegion}}