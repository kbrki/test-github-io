# {{page-title}}   
Die folgenden Unterseiten geben einen Überblick über die für die Erkrankungsmeldung erstellten und erweiterten ValueSets. Dabei wird grob auf deren Inhalt und Verwendungszwecke eingegangen.
