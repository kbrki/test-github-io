# {{page-title}} 
[https://demis.rki.de/fhir/ValueSet/answerSetMilitaryAffiliation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetmilitaryaffiliation)   

Enthält zusätzlich zu den Konzepte aus [https://demis.rki.de/fhir/CodeSystem/militaryAffiliation](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/codesystem/militaryaffiliation) zwei Null-Flavors, um z.B. darauf hinweisen zu können, dass eine Information nicht erfragt wurde oder nicht ermittelbar ist.  

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetMilitaryAffiliation}}