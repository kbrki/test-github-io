# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/answerSetFormBAND](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/answersetformband)

Das ValueSet enthält für Milzbrand spezifische Krankheitsformen. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/answerSetFormBAND}}
