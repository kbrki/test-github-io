# {{page-title}}
[https://demis.rki.de/fhir/ValueSet/evidenceCLOD](https://simplifier.net/demisarztmeldung/~resources?canonical=https://demis.rki.de/fhir/valueset/evidenceclod)

Das ValueSet enthält für Botulismus spezifische Symtome/Manfestationen der Erkrankung. Alle referenzierten Konzepte stammen aus SNOMED-CT.

**Inhalte**
{{render:https://demis.rki.de/fhir/ValueSet/evidenceCLOD}}
