# {{page-title}} 
Die folgenden Unterseiten beschreiben mögliche Implementierungsszenarien für die Umsetzung der Hospitalisierungsmeldung.