##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMRSP](https://simplifier.net/demis/specimenMRSP)

{{tree:SpecimenMRSP, hybrid}}