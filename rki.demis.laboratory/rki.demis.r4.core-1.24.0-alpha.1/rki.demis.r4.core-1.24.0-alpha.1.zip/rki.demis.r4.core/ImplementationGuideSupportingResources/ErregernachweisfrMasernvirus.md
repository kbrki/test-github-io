##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMSVP](https://simplifier.net/demis/pathogendetectionmsvp)

{{tree:PathogenDetectionMSVP, hybrid}} 