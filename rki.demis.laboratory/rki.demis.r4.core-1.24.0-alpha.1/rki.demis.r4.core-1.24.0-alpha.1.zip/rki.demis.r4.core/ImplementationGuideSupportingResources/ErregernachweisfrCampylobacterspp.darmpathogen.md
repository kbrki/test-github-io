##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCAMP](https://simplifier.net/demis/pathogendetectioncamp)

{{tree:PathogenDetectionCAMP, hybrid}}