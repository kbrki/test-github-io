##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenSALP](https://simplifier.net/demis/specimenSALP)

{{tree:SpecimenSALP, hybrid}}