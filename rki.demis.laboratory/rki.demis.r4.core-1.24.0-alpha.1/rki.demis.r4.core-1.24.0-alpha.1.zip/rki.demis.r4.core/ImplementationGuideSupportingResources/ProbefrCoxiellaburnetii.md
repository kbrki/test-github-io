##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCOXP](https://simplifier.net/demis/specimencoxp)

{{tree:SpecimenCOXP, hybrid}}