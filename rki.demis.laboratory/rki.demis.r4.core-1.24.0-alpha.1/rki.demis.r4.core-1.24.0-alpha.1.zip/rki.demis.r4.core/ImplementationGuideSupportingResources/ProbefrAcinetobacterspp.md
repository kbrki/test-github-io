##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenYENP](https://simplifier.net/demis/specimenYENP)

{{tree:https://demis.rki.de/fhir/StructureDefinition/SpecimenACBP, hybrid}}