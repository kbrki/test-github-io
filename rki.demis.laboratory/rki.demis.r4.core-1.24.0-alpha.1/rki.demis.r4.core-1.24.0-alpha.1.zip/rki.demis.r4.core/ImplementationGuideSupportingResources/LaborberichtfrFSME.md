##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportFSVP](https://simplifier.net/demis/laboratoryreportfsvp)

{{tree:laboratoryreportfsvp, hybrid}}