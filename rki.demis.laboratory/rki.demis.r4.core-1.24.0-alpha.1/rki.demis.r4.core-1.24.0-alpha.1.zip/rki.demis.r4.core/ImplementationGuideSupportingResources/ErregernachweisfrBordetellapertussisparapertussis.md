##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionBPSP](https://simplifier.net/demis/pathogendetectionbpsp)

{{tree:PathogenDetectionBPSP, hybrid}}