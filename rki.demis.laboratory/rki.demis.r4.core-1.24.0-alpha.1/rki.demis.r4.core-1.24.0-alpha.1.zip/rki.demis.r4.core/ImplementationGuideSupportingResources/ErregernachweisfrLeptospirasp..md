##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionLEPP](https://simplifier.net/demis/pathogendetectionlepp)

{{tree:PathogenDetectionLEPP, hybrid}} 