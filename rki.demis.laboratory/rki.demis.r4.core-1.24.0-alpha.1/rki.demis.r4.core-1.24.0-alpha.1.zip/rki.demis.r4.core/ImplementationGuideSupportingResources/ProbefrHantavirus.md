##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHTVP](https://simplifier.net/demis/specimenHTVP)

{{tree:SpecimenHTVP, hybrid}}