##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCOXP](https://simplifier.net/demis/pathogendetectioncoxp)

{{tree:PathogenDetectionCOXP, hybrid}}  