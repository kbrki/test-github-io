##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCHLP](https://simplifier.net/demis/pathogendetectionchlp)

{{tree:PathogenDetectionCHLP, hybrid}} 