##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCLOP](https://simplifier.net/demis/specimenCLOP)

{{tree:SpecimenCLOP, hybrid}}