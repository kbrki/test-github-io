##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionGILP](https://simplifier.net/demis/pathogendetectiongilp)

{{tree:PathogenDetectionGILP, hybrid}}