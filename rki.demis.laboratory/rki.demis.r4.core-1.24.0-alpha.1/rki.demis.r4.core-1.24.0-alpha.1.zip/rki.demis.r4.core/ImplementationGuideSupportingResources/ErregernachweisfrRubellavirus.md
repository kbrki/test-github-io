##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionRUVP](https://simplifier.net/demis/pathogendetectionruvp)

{{tree:PathogenDetectionRUVP, hybrid}} 