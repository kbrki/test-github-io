##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionNEIP](https://simplifier.net/demis/pathogendetectionneip)

{{tree:PathogenDetectionNEIP, hybrid}}