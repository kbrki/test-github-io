##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenSPNP](https://simplifier.net/demis/specimenSPNP)

{{tree:SpecimenSPNP, hybrid}}