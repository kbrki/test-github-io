##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportSPNP](https://simplifier.net/demis/laboratoryreportspnp)

{{tree:laboratoryreportspnp, hybrid}}