##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMRSP](https://simplifier.net/demis/laboratoryreportmrsp)

{{tree:laboratoryreportmrsp, hybrid}}