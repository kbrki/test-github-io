##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHINP](https://simplifier.net/demis/specimenHINP)

{{tree:SpecimenHINP, hybrid}}