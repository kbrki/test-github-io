##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenOPXP](https://simplifier.net/demis/specimenOPXP)

{{tree:SpecimenOPXP, hybrid}}
