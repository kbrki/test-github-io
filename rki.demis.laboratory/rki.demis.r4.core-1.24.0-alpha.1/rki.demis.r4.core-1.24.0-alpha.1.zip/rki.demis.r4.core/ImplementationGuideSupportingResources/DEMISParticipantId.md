##### {{page-title}}

[https://demis.rki.de/fhir/NamingSystem/DEMISParticipantId](https://simplifier.net/demis/demisparticipantid)

Die DemisParticipantId (DEMIS-Teilnehmernummer) wird genutzt, um DEMIS-Teilnehmer (Melder, Gesundheitsämter etc.) innerhalb des Systems eindeutig identifizieren zu können. Die Herausgabe von Identifiern innerhalb dieses NamingSystems erfolgt durch das Robert Koch-Institut. 

Die DemisParticipantId wird in naher Zukunft die DemisLaboratoryId ersetzen.

{{tree:demisparticipantid, hybrid}}