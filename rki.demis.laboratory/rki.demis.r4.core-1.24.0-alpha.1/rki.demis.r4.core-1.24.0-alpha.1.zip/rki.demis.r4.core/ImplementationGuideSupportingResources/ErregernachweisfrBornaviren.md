##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionBOVP](https://simplifier.net/demis/pathogendetectionbovp)

{{tree:PathogenDetectionBOVP, hybrid}} 