##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportGFVP](https://simplifier.net/demis/laboratoryreportgfvp)

{{tree:laboratoryreportgfvp, hybrid}}