##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCRYP](https://simplifier.net/demis/specimenCRYP)

{{tree:SpecimenCRYP, hybrid}}