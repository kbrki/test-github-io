##### Erkrankungshäufung

[https://demis.rki.de/fhir/StructureDefinition/Outbreak](https://simplifier.net/demis/outbreak)

{{tree:outbreak, hybrid}}

