##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenYPSP](https://simplifier.net/demis/specimenYPSP)

{{tree:SpecimenYPSP, hybrid}}