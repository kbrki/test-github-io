##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenBORP](https://simplifier.net/demis/specimenBORP)

{{tree:SpecimenBORP, hybrid}}