##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMBVP](https://simplifier.net/demis/specimenMBVP)

{{tree:SpecimenMBVP, hybrid}}