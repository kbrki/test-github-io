##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHTVP](https://simplifier.net/demis/laboratoryreporthtvp)

{{tree:laboratoryreporthtvp, hybrid}} 
