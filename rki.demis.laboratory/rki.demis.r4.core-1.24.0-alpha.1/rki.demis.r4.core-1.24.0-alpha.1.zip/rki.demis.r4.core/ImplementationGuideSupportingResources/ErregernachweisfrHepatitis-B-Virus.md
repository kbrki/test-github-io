##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHBVP](https://simplifier.net/demis/pathogendetectionhbvp)

{{tree:PathogenDetectionHBVP, hybrid}} 