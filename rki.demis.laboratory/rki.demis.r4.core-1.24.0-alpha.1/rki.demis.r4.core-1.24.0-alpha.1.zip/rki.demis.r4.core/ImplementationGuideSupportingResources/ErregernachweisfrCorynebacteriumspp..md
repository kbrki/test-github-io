##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCORP](https://simplifier.net/demis/pathogendetectionedncorp)

{{tree:PathogenDetectionCORP, hybrid}}