##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportABVP](https://simplifier.net/demis/laboratoryreportabvp)

{{tree:laboratoryreportabvp, hybrid}}