##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenBPSP](https://simplifier.net/demis/specimenBPSP)

{{tree:SpecimenBPSP, hybrid}}