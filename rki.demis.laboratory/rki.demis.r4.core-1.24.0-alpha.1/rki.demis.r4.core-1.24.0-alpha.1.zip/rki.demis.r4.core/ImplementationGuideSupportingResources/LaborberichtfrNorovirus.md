##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportNOVP](https://simplifier.net/demis/laboratoryreportnovp)

{{tree:laboratoryreportnovp, hybrid}}