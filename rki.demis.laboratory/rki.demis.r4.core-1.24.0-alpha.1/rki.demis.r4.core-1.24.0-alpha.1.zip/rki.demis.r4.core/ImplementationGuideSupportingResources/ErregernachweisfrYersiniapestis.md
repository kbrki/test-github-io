##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionYPSP](https://simplifier.net/demis/pathogendetectionypsp)

{{tree:PathogenDetectionYPSP, hybrid}}