##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMYTP](https://simplifier.net/demis/pathogendetectionmytp)

{{tree:PathogenDetectionMYTP, hybrid}}