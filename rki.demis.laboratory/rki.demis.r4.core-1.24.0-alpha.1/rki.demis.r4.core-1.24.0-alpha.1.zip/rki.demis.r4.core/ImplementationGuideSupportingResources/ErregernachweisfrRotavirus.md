##### Rotavirus-Erregernachweis

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionRTVP](https://simplifier.net/demis/pathogendetectionrtvp)

{{tree:PathogenDetectionRTVP, hybrid}}
