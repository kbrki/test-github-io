##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionACBP](https://simplifier.net/demis/pathogendetectionacbp)

{{tree:PathogenDetectionACBP, hybrid}} 