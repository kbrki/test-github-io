##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportBANP](https://simplifier.net/demis/laboratoryreportbanp)

{{tree:laboratoryreportbanp, hybrid}}