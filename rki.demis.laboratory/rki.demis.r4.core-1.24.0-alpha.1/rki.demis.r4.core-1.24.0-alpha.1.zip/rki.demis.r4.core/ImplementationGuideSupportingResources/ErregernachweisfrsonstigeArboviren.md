##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionABVP](https://simplifier.net/demis/pathogendetectionabvp)

{{tree:PathogenDetectionABVP, hybrid}}