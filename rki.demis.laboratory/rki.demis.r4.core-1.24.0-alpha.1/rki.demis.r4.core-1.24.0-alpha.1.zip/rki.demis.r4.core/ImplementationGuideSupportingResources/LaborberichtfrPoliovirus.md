##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportPOVP](https://simplifier.net/demis/laboratoryreportpovp)

{{tree:laboratoryreportpovp, hybrid}}