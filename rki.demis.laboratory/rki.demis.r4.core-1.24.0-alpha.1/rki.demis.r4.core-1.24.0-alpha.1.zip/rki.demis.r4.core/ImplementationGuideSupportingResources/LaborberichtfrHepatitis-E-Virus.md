##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHEVP](https://simplifier.net/demis/laboratoryreporthevp)

{{tree:laboratoryreporthevp, hybrid}}