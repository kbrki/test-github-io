#### {{page-title}}

[https://demis.rki.de/fhir/ConceptMap/LOINCMaterialToSNOMEDMaterial](https://simplifier.net/demis/loincmaterialtosnomedmaterial)

Beinhaltet ein Mapping von LOINC-Materialen auf SNOMED-Materialien.

Mit Hilfe der ConceptMap LOINCMaterialToSNOMEDMaterial ist abzuleiten, welcher SNOMED-Code in Specimen.type anzugeben ist, abhängig vom Material des LOINC-Codes, welcher in Observation.code angegeben ist. 

{{tree:loincmaterialtosnomedmaterial, hybrid}}
