##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportDENP](https://simplifier.net/demis/laboratoryreportdenp)

{{tree:laboratoryreportdenp, hybrid}}