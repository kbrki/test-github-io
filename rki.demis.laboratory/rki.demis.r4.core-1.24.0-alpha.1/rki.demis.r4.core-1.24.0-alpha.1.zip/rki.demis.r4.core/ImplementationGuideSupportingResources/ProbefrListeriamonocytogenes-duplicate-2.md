##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenLISP](https://simplifier.net/demis/specimenLISP)

{{tree:SpecimenLISP, hybrid}}