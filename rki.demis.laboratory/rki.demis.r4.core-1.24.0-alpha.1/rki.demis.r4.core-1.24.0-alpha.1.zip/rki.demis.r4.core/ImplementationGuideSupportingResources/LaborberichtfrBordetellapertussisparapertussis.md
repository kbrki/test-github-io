##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportBPSP](https://simplifier.net/demis/laboratoryreportbpsp)

{{tree:laboratoryreportbpsp, hybrid}}