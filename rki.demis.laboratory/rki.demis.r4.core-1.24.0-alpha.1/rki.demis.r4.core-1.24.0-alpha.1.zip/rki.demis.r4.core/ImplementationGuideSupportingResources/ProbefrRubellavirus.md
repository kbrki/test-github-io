##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenRUVP](https://simplifier.net/demis/specimenRUVP)

{{tree:SpecimenRUVP, hybrid}}