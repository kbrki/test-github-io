##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportEHCP](https://simplifier.net/demis/laboratoryreportehcp)

{{tree:laboratoryreportehcp, hybrid}}