##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportLSVP](https://simplifier.net/demis/laboratoryreportlsvp)

{{tree:laboratoryreportlsvp, hybrid}}
