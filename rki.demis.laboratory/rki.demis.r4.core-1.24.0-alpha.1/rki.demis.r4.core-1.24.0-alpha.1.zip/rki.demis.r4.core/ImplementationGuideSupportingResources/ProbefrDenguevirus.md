##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenDENP](https://simplifier.net/demis/specimenDENP)

{{tree:SpecimenDENP, hybrid}}