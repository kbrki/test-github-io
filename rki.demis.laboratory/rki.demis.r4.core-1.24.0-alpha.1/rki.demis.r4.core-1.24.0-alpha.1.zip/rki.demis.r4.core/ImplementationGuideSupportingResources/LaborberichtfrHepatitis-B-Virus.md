##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHBVP](https://simplifier.net/demis/laboratoryreporthbvp)

{{tree:laboratoryreporthbvp, hybrid}}