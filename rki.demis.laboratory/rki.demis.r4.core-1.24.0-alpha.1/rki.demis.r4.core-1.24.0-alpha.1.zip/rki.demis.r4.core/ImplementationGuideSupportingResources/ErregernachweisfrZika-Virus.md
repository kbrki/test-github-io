###### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionZKVP](https://simplifier.net/demis/pathogendetectionzkvp)

{{tree:PathogenDetectionZKVP, hybrid}}