##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionPOVP](https://simplifier.net/demis/pathogendetectionpovp)

{{tree:PathogenDetectionPOVP, hybrid}} 