##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenVZVP](https://simplifier.net/demis/specimenVZVP)

{{tree:SpecimenVZVP, hybrid}}