##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMYLP](https://simplifier.net/demis/specimenMYLP)

{{tree:SpecimenMYLP, hybrid}}