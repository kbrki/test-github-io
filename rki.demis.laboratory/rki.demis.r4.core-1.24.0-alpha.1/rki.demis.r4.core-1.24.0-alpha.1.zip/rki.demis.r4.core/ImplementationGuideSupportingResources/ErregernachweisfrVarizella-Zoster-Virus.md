##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionVZVP](https://simplifier.net/demis/pathogendetectionvzvp)

{{tree:PathogenDetectionVZVP, hybrid}}