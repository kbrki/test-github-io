###### {{page-title}}

{{render:laboratoryTestRICP}}