##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionWNVP](https://simplifier.net/demis/pathogendetectionwnvp)

{{tree:PathogenDetectionWNVP, hybrid}}