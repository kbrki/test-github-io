##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenLSVP](https://simplifier.net/demis/specimenLSVP)

{{tree:SpecimenLSVP, hybrid}}