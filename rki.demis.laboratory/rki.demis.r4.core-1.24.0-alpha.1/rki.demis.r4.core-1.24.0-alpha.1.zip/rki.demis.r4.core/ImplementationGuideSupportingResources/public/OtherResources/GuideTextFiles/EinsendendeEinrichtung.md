##### Einsendende Einrichtung

[https://demis.rki.de/fhir/StructureDefinition/SubmittingFacility](https://simplifier.net/demis/submittingfacility)

Die Einsender-Einrichtung enthält die Angaben der einsendenden Einrichtung. Die Informationen werden vom zuständigen Gesundsamt zur  Kontaktaufnahme genutzt.

{{tree:SubmittingFacility, hybrid}}

Beispiel:

{{xml:submittingfacility-example}}