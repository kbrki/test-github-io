#### Erregernachweismeldevorgang

[https://demis.rki.de/fhir/StructureDefinition/NotificationBundleLaboratory](https://simplifier.net/demis/notificationbundlelaboratory)

Der Erregernachweismeldevorgang ist vom Meldevorgang abgeleitet und bildet den Container für genau eine Erregernachweismeldung. 

{{tree:NotificationBundleLaboratory, hybrid}}

Beispiel:

{{xml:notificationBundleLaboratory-example}}