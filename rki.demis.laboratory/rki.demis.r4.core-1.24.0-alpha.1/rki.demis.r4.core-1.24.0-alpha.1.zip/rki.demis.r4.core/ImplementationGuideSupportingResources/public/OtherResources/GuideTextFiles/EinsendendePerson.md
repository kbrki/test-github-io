##### Einsendende Person

[https://demis.rki.de/fhir/StructureDefinition/SubmittingPerson](https://simplifier.net/demis/submittingperson)

Der Einsender umfasst die Informationen zur Person, die die Probe einsendet. Er muss in der Meldung enthalten sein, wenn die Einsender-Einrichtung nicht enthalten ist.

{{tree:SubmittingPerson, hybrid}}

Beispiel:

{{xml:submittingperson-example}}