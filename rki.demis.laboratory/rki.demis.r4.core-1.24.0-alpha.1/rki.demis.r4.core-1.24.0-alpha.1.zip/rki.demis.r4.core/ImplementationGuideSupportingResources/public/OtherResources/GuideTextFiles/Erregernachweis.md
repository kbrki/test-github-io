#### Erregernachweis

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetection](https://simplifier.net/demis/pathogendetection)

Der Erregernachweis enthält die Angaben zum durchgeführten Labortest und das Ergebnis. 

{{tree:PathogenDetection, hybrid}}
