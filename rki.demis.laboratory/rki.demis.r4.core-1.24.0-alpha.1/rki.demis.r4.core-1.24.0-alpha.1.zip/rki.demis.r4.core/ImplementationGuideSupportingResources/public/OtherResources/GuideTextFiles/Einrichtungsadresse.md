#### Einrichtungsadresse

[https://demis.rki.de/fhir/StructureDefinition/FacilityAddressNotifiedPerson](https://simplifier.net/demis/facilityaddressnotifiedperson)

Über die Einrichtungsadresse kann eine Einrichtung (sog. Betroffenen-Einrichtung) als Aufenthaltsort für die Betroffene Person angegeben werden.

{{tree:FacilityAddressNotifiedPerson, hybrid}}

Beispiel:

{{xml:FacilityAddressNotifiedPerson-example}}