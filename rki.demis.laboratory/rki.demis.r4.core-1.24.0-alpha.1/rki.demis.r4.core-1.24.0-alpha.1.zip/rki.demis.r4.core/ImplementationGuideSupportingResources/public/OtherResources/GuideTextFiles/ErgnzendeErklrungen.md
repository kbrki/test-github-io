## Ergänzende Erklärungen

### Bedeutung von MustSupport

Mit der MustSupport-Markierung eines Elementes wird zusätzlich zu der Kardinalität eine Information darüber vorgegeben inwieweit ein Element unterstützt werden muss.

**Aus Sicht der GA-Fachverfahren bedeutet das:**  
Die entsprechende Information MUSS dem Nutzer mindestens angezeigt werden können. Die entsprechende Information SOLL ins interne Informationsmodelle der Anwendung überführt werden. Die Überführung kann ein einfaches Kopieren oder komplexeres Mappen der Daten sein.

**Aus Sicht der meldenden Systeme bedeutet das:**  
Die entsprechende Information SOLL durch die Anwendung bereitgestellt werden, sofern sie vorhanden ist.


### Bedeutung von partOf

Bei Einrichtungen kann unter "partOf" eine Referenz auf die übergeordnete Einrichtung angegeben werden. Z.B. für das "Nationale Referenzzentrum für Influenzaviren" ist das RKI die übergeordnete Einrichtung. 

Die übergeordnete Einrichtung wird unter Verwendung des FHIR-Profiles [Organization](https://www.hl7.org/fhir/organization.html) angegeben. Es genügt die Angabe von Einrichtungsname und Adresse. Diese Informationen sollen von der Anwendung der GA-Fachverfahren dargestellt werden.