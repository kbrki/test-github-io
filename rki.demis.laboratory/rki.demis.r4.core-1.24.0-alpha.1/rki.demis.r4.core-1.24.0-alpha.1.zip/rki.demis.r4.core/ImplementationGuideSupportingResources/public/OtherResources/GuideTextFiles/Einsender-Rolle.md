#### Einsender-Rolle

[https://demis.rki.de/fhir/StructureDefinition/SubmittingRole](https://simplifier.net/demis/submittingrole)

Die Einsender-Rolle ist erforderlich, um eine Unterscheidung zwischen Einsender und Einsender-Einrichtung vornehmen zu können. Sie beinhaltet lediglich Verweise entweder auf die Einsendende Person oder auf die Einsendende Einrichtung.

{{tree:SubmittingRole, hybrid}}

Beispiele:

**Verweis auf eine Einsendende Person**

{{xml:submittingrole-submittingperson-example}}

**Verweis auf eine Einsendende Einrichtung**

{{xml:submittingrole-submittingfacility-example}}