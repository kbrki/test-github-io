### Betroffene Person (nichtnamentlich)

[https://demis.rki.de/fhir/StructureDefinition/NotifiedPersonNotByName](https://simplifier.net/demis/notifiedpersonnotbyname)

{{tree:NotifiedPersonNotByName, hybrid}}

Beispiel:

{{xml:example-patient-notifiedpersonnotbyname-01}}
