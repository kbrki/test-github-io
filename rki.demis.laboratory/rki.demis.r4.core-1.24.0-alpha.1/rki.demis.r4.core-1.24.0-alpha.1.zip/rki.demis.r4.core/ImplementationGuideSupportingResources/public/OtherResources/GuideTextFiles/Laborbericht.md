#### Laborbericht

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReport](https://simplifier.net/demis/laboratoryreport)

Der Laborbericht kann mehrere Erregernachweise zu einer Probe enthalten und umfasst eine Gesamtbewertung der Ergebnisse aller Einzeltests.

Der Laborbericht fasst die Ergebnisse der Einzeltests (Erregernachweise) sowohl kodiert als auch in textueller Form zusammen.

Die Information zum jeweils zutreffenden Meldetatbestand werden in DiagnosticReport.code angegeben. 

{{tree:laboratoryreport, hybrid}}