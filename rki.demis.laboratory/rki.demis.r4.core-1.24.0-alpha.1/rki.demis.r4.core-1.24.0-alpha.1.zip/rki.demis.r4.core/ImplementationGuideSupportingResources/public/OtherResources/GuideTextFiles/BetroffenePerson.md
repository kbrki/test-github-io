### Betroffene Person

[https://demis.rki.de/fhir/StructureDefinition/NotifiedPerson](https://simplifier.net/demis/notifiedperson)

Die betroffene Person enthält relevante Angaben zum Patienten, die entsprechend der aktuellen Planung aus den Auftragsdaten extrahiert werden, die der Einsender dem jeweiligen Labor übermittelt hat. Dies werden in der Mehrzahl der Fälle die Angaben von der eGK der betroffenen Person sein (Versichertenstammdaten).

Die als betroffene Person in der Erregernachweismeldung angegebene Patient-Ressource muss im Laborbericht, im Erregernachweis, in der Probe und in der Diagnose als "subject" referenziert werden.

Patient.name: In diesem Element muss der Name der betroffenen Person angegeben werden. Dabei sind – anders als im zugrundeliegenden deutschen Basisprofil – mindestens Vor- und Nachname (HumanName.given und HumanName.family) verpflichtend anzugeben. Diese Angaben sind für eine personenfokussierte Fallbearbeitung innerhalb des Gesundheitsamtes unerlässlich und werden daher über das Profil zwingend eingefordert.  

Patient.telecom: Über dieses Element sollen Angaben übermittelt werden, die die Mitarbeiter im Gesundheitsamt in die Lage versetzen, die betroffene Person schnell zu kontaktieren.  

Patient.deceased[x]: Über die spezifischen Ausprägungen dieses Elements können Angaben dazu gemacht werden, ob bzw. wann die betroffene Person verstorben ist. 

HINWEIS: Im Rahmen der Arztmeldung werden Angaben zum Tod der betroffenen Person ebenfalls an einer anderen Stelle innerhalb der Meldung strukturiert abgefragt/erfasst. In diesem Fall sollte Patient.deceased[x] NICHT befüllt werden. Alternativ muss sichergestellt werden, dass sich die in den verschiedenen Teilen der Meldung getroffenen Aussagen nicht widersprechen. 

Patient.address: Über diese Elemente können Angaben zu Aufenthaltsorten der betroffenen Person kommuniziert werden. Die Vollständigkeit und Korrektheit der Angaben ist dabei für das Meldesystem von herausragender Bedeutung, da auf Grundlage dieser Informationen die automatisierte Ermittlung des jeweils zuständigen Gesundheitsamtes erfolgt. Unvollständige oder inkorrekte Angaben führen zu deutlichen Mehraufwänden in den Gesundheitsämtern, da die Zuständigkeit dann ggf. erneut manuell ermittelt werden muss und somit Verzögerungen bei der Fallanlage und -bearbeitung entstehen.
Grundsätzlich können und sollen mehrere Aufenthaltsorte (als individuelle address-Elemente) angegeben werden, sofern die entsprechenden Informationen dem Melder vorliegen. DEMIS unterscheidet in diesem Zusammenhang für die betroffene Person drei verschiedene „Arten“ von Aufenthaltsorten: (1) den derzeitigen Aufenthaltsort, (2) den gewöhnlichen Aufenthaltsort und (3) den Hauptwohnsitz. Die Information, um welche Art von Aufenthaltsort es sich bei der jeweils angegebenen Adresse handelt, erfolgt über die definierte AddressUse-Extension.
Sofern es sich bei einem der angegebenen Aufenthaltsorte um eine Einrichtung handelt (z.B. ein Pflegeheim als „Hauptwohnsitz“ oder ein Krankenhaus als „derzeitiger Aufenthaltsort“), muss eine separate Einrichtungsressource (https://demis.rki.de/fhir/StructureDefinition/NotifiedPersonFacility) als Bestandteil der Meldung erstellt und aus der address heraus auf diese verwiesen werden. Der Verweis erfolgt hierbei über die definierte FacilityAddressNotifiedPerson-Extension. Wird auf eine entsprechende Einrichtungs-Ressource verwiesen, werden deren Adressangaben beim Meldungsrouting berücksichtigt. Die Angaben zu Straße, Stadt, Land usw. können dann im jeweiligen address-Element der betroffenen Person entfallen. 

HINWEISE: 
-	Das der Profilierung zugrundeliegenden konzeptionelle Modell unterstützt grundsätzlich die Abbildung komplexer Adresskonstellationen. Es wäre beispielsweise vorstellbar, dass eine betroffene Person, die dauerhaft in einem Pflegeheim untergebracht ist, in einem Krankenhaus aufgenommen wird, aus welchem heraus die Meldung erfolgt. Entsprechend wären für die betroffene Person zwei address-Elemente mit verschiedenen AddressUses (Hauptwohnsitz + derzeitiger Aufenthaltsort) anzulegen, aus denen heraus auf zwei unterschiedliche Instanzen (Pflegeheim + Krankenhaus) der Betroffenen-Einrichtung (https://demis.rki.de/fhir/StructureDefinition/NotifiedPersonFacility) verwiesen wird. 
-	In Abhängigkeit des Melders und der Art der Meldung werden sich die zur Verfügung stehenden Adressinformationen jedoch sehr stark unterscheiden. Meldende Labore verfügen häufig nur über die als Bestandteil des Laborauftrags übermittelten Adressangaben der betroffenen Person. Eine direkte Rückfrage beim Patienten bzgl. der spezifischen Aufenthaltssituation ist hier eher problematisch. Andere Meldergruppen (z.B. Melder in Arztpraxen und Krankenhäuser) haben (bei gesetzlich Versicherten) beispielsweise direkten Zugriff auf die Versichertenstammdaten der eGK mit einem qualitativ hochwertigen Datensatz zum Hauptwohnsitz. Andere Aufenthaltsorte ergeben sich ggf. aus dem Kontext (z.B. Hospitalisierung  derzeitiger Aufenthaltsort ist dann der jeweilige Krankenhausstandort) oder können direkt bei der betroffenen Person erfragt werden. Bei der Umsetzung in den IT-Systemen der Melder sind entsprechende Konstellationen mitzudenken und anforderungsgerecht umzusetzen. 

Patient.contact: Über dieses Element können Angaben zu Personen gemacht werden, die alternativ durch das Gesundheitsamt kontaktiert werden können. Dies können beispielsweise Angehörige oder Betreuer sein, sofern die betroffene Person nicht selbst in der Lage ist, auf potentielle Rückfragen des Gesundheitsamtes zu reagieren.


{{tree:NotifiedPerson, hybrid}}

Beispiel:

{{xml:notifiedPerson-example}}


