#### Übermittlungsstelle

Das CodeSystem enthält die Liste der Übermittlungsstellen.

{{render:reportingsite}}