#### Adressnutzung

[https://demis.rki.de/fhir/StructureDefinition/AddressUse](https://simplifier.net/demis/addressuse-duplicate-2)

Über die Adressnutzung kann die Art des Aufenthaltsortes der Betroffenen Person übermittelt werden.  
Die Adressnutzung wird in einem Coding-Element unter Verwendung des ValueSets https://demis.rki.de/fhir/ValueSet/addressUse angegeben.

{{tree:addressuse-duplicate-2, hybrid}}

Beispiel: 

{{xml:addressuse-example}}