#### DemisLaboratoryId

[https://demis.rki.de/fhir/NamingSystem/DemisLaboratoryId](https://simplifier.net/demis/demislaboratoryid-duplicate-4)

Die DemisLaboratoryId ist das NamingSystem um den von DEMIS vergebenen Identifier (DEMIS-Labornummer) des Melders anzugeben. 

{{tree:demislaboratoryid-duplicate-4, hybrid}}

**Hinweis**: Das angegebene NamingSystem https://fhir.kbv.de/NamingSystem/DemisLaboratoryId, wie in dem Beispiel https://simplifier.net/demis/notifierfacility-example-2 angegeben, **SOLL NICH VERWENDET WERDEN**.
Das Beispiel wird in der kommenden Version 1.22.1 korrigiert.

**Korrektes Beispiel**:

```xml

<Organization xmlns="http://hl7.org/fhir">
    <id value="NotifierFacility-example-2" />
    <meta>
        <profile value="https://demis.rki.de/fhir/StructureDefinition/NotifierFacility" />
    </meta>
    <identifier>
        <system value="https://demis.rki.de/fhir/NamingSystem/DemisLaboratoryId" />
        <value value="12345" />
    </identifier>
    <type>
        <coding>
            <system value="https://demis.rki.de/fhir/CodeSystem/organizationType" />
            <code value="laboratory" />
        </coding>
    </type>
    <name value="Labor Mondschein" />
    <telecom>
        <system value="phone" />
        <value value="+49 (0)2738 - 123456" />
        <use value="work" />
    </telecom>
    <address>
        <line value="Seeweg 16" />
        <city value="Berlin" />
        <state value="DE-BE" />
        <postalCode value="10117" />
        <country value="20422" />
    </address>
</Organization>

```

