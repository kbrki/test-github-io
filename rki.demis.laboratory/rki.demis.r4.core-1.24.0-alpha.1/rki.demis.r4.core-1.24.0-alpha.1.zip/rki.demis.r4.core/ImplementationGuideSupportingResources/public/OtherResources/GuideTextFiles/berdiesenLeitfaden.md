### Über diesen Leitfaden

Die Coronavirus-Meldeverordnung sieht für Labore eine Meldepflicht an die zuständigen Gesundheitsämter für den Nachweis von SARS-CoV-2 vor, soweit der Nachweis auf eine akute Infektion hinweist. Seit Juni 2020 haben Labore die Möglichkeit, Erregernachweise von SARS-CoV-2 elektronisch mit dem Deutschen Elektronischen Melde- und Informationssystem für den Infektionsschutz ([DEMIS](https://www.rki.de/DE/Content/Infekt/IfSG/DEMIS/DEMIS_node.html)) zu melden.
Im Infektionsschutzgesetz ist definiert, welche Informationen bzw. welche Arten von Informationen vom Labor an die zuständigen Gesundheitsämter zu melden sind. 

Die in diesem Implementierungsleitfaden vorgestellten [FHIR](https://www.hl7.org/fhir/)-Ressourcen strukturieren die Meldeinhalte und definieren das Datenmodell der DEMIS-FHIR-Schnittstelle.

### Zielgruppe

Dieser Leitfaden richtet sich an 

- Softwarehersteller von Laborinformationssystemen, die eine tiefe Integration der DEMIS-FHIR-Schnittstelle in ihren Systemen umsetzen
- Softwarehersteller von GA-Fachverfahren 

### Aufbau dieses Implementierungsleitfadens

Dieser Leitfaden enthält

- Strukturelle Vorgaben in Form von FHIR-Profilen für diverse FHIR Ressourcen (Siehe Abschnitt StructureDefinitions)
- FHIR-Extensions (Siehe Abschnitt Extensions)
- OperationDefinitions (Siehe Abschnitt OperationDefinitions)
 - Semantische Vorgaben in Form von ValueSets, Codesystemen und NamingSystems (Siehe Abschnitt Terminologien)

Hinweise und Beispiele zur Anwendung dieser Ressourcen finden sich in den  Erklärungen zu den einzelnen Ressourcen. Beispiele komplexer Meldeszenarien finden sich in der [DEMIS Wissensdatenbank](https://wiki.gematik.de/display/DSKB/Neue+Profilversionen).
