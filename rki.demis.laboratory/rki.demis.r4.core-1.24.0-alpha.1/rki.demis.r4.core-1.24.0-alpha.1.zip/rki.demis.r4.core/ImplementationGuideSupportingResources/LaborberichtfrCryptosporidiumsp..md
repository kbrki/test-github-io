##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCRYP](https://simplifier.net/demis/laboratoryreportcryp)

{{tree:laboratoryreportcryp, hybrid}}