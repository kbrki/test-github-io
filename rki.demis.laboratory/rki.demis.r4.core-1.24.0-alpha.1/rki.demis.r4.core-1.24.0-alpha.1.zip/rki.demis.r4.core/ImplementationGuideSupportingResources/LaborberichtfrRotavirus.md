##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportRTVP](https://simplifier.net/demis/laboratoryreportrtvp)

{{tree:laboratoryreportrtvp, hybrid}}

