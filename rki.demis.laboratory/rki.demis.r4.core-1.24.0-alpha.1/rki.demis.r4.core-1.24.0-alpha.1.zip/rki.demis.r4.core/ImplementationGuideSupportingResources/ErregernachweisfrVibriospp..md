##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionVCHP](https://simplifier.net/demis/pathogendetectionvchp)

{{tree:PathogenDetectionVCHP, hybrid}}