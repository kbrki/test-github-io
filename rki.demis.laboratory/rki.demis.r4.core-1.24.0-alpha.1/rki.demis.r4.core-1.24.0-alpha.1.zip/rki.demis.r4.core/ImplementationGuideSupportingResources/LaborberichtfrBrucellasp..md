##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportBRUP](https://simplifier.net/demis/laboratoryreportbrup)

{{tree:laboratoryreportbrup, hybrid}}