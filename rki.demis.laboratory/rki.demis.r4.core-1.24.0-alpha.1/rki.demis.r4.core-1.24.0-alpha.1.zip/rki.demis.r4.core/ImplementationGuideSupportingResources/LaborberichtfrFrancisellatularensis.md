##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportFRTP](https://simplifier.net/demis/laboratoryreportfrtp)

{{tree:laboratoryreportfrtp, hybrid}}