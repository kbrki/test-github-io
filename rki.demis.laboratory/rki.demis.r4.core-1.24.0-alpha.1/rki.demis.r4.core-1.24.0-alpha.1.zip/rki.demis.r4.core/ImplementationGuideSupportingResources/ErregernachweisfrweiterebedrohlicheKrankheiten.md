##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionWBKP](https://simplifier.net/demis/pathogendetectionwbkp)

{{tree:PathogenDetectionWBKP, hybrid}}