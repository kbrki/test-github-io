##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHAVP](https://simplifier.net/demis/specimenHAVP)

{{tree:SpecimenHAVP, hybrid}}