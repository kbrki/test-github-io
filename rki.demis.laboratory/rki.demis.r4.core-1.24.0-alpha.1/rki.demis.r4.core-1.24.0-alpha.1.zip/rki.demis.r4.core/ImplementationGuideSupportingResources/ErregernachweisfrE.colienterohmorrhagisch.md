##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionEHCP](https://simplifier.net/demis/pathogendetectionehcp)

{{tree:PathogenDetectionEHCP, hybrid}}