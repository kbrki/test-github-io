##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHFAP](https://simplifier.net/demis/pathogendetectionhfap)

{{tree:PathogenDetectionHFAP, hybrid}}