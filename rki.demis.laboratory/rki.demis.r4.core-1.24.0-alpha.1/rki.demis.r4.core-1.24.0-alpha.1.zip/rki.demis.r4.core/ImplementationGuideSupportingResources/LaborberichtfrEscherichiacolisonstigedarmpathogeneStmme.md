##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportECOP](https://simplifier.net/demis/laboratoryreportecop)

{{tree:laboratoryreportecop, hybrid}}