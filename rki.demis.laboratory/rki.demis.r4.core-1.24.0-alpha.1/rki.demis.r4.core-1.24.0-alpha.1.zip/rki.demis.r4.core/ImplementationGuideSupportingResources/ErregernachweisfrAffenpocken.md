###### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMPXP](https://simplifier.net/demis/pathogendetectionmpxp)

{{tree:PathogenDetectionMPXP, hybrid}}
