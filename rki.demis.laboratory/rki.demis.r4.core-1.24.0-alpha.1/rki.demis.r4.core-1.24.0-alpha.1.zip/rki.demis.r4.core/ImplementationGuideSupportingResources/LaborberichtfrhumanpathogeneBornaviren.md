##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportBOVP](https://simplifier.net/demis/laboratoryreportbovp)

{{tree:laboratoryreportbovp, hybrid}}