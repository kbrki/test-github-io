##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenGFVP](https://simplifier.net/demis/specimenGFVP)

{{tree:SpecimenGFVP, hybrid}}