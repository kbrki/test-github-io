##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionBORP](https://simplifier.net/demis/pathogendetectionborp)

{{tree:PathogenDetectionBORP, hybrid}}