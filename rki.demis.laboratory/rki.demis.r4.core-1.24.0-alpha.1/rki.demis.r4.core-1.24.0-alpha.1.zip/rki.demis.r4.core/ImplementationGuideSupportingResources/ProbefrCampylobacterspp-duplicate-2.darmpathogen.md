##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCAMP](https://simplifier.net/demis/specimenCAMP)

{{tree:SpecimenCAMP, hybrid}}