##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHDVP](https://simplifier.net/demis/specimenHDVP)

{{tree:SpecimenHDVP, hybrid}}