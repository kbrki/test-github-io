##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenLEGP](https://simplifier.net/demis/specimenLEGP)

{{tree:SpecimenLEGP, hybrid}}