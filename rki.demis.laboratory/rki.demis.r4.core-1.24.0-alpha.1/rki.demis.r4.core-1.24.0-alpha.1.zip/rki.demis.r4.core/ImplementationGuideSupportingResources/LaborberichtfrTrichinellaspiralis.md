##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportTRIP](https://simplifier.net/demis/laboratoryreporttrip)

{{tree:laboratoryreporttrip, hybrid}}