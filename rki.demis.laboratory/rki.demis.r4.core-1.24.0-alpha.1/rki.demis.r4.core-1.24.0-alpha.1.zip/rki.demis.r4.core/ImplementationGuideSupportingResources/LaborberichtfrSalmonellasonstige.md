##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportSALP](https://simplifier.net/demis/laboratoryreportsalp)

{{tree:laboratoryreportsalp, hybrid}}