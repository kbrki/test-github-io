##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionTRIP](https://simplifier.net/demis/pathogendetectiontrip)

{{tree:PathogenDetectionTRIP, hybrid}}