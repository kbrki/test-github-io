##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportVZVP](https://simplifier.net/demis/laboratoryreportvzvp)

{{tree:laboratoryreportvzvp, hybrid}}