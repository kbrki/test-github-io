###### {{page-title}}

{{render:answerSetResistance}}