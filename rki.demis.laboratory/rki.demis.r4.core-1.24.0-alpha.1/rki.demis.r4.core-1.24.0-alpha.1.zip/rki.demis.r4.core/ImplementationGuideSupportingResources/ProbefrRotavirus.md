##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenRTVP](https://simplifier.net/demis/specimenRTVP)

{{tree:SpecimenRTVP, hybrid}}