##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionNOVP](https://simplifier.net/demis/pathogendetectionnovp)

{{tree:PathogenDetectionNOVP, hybrid}}