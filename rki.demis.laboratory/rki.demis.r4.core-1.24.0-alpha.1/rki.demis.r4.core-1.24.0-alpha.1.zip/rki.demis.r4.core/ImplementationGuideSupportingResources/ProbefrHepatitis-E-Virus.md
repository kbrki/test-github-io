##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHEVP](https://simplifier.net/demis/specimenHEVP)

{{tree:SpecimenHEVP, hybrid}}