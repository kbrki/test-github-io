##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportEBVP](https://simplifier.net/demis/laboratoryreportebvp)

{{tree:laboratoryreportebvp, hybrid}}