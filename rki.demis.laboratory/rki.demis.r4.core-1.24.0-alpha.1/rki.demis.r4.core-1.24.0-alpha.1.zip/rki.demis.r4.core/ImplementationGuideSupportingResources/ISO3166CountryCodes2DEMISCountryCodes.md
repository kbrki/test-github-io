##### ISO3166CountryCodes2DEMISCountryCodes
[https://demis.rki.de/fhir/ConceptMap/ISO3166CountryCodes2DEMISCountryCodes](https://simplifier.net/demis/iso3166countrycodes2demiscountrycodes-duplicate-3)

Zur Angabe des Landes soll das ValueSet [country](https://simplifier.net/demis/country-duplicate-2) verwendet werden. 
Bei Vorliegen der ISO-Ländercodes lässt sich 
über die ConceptMap ISO3166CountryCodes2DEMISCountryCodes ableiten welcher DEMIS-Ländercode zu verwenden ist. 

{{tree:iso3166countrycodes2demiscountrycodes-duplicate-3, hybrid}}
