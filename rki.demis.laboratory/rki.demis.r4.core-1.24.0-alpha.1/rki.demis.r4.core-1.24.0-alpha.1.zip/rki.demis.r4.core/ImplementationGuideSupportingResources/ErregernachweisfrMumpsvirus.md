##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMPVP](https://simplifier.net/demis/pathogendetectionmpvp)

{{tree:PathogenDetectionMPVP, hybrid}} 