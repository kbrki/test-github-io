##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportRICP](https://simplifier.net/demis/laboratoryreportricp)

{{tree:laboratoryreportricp, hybrid}}