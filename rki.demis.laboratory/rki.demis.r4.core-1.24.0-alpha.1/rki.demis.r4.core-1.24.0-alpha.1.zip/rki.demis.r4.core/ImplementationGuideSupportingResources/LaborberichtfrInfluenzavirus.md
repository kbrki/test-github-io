##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportINVP](https://simplifier.net/demis/laboratoryreportinvp)

{{tree:laboratoryreportinvp, hybrid}}
