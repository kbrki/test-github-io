##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenWBKP](https://simplifier.net/demis/specimenWBKP)

{{tree:SpecimenWBKP, hybrid}}