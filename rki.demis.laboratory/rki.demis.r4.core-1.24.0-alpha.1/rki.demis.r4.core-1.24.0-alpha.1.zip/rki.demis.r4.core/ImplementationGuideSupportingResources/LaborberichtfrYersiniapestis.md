##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportYPSP](https://simplifier.net/demis/laboratoryreportypsp)

{{tree:laboratoryreportypsp, hybrid}}