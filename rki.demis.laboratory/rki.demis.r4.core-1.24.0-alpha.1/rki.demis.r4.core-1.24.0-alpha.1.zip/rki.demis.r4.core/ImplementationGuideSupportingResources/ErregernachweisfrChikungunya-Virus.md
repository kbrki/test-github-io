##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCKVP](https://simplifier.net/demis/pathogendetectionednckvp)

{{tree:PathogenDetectionCKVP, hybrid}}