##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCAMP](https://simplifier.net/demis/laboratoryreportcamp)

{{tree:laboratoryreportcamp, hybrid}}