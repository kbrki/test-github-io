##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenFRTP](https://simplifier.net/demis/specimenFRTP)

{{tree:SpecimenFRTP, hybrid}}