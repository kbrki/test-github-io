##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportLISP](https://simplifier.net/demis/laboratoryreportlisp)

{{tree:laboratoryreportlisp, hybrid}}