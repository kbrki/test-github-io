##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenSTYP](https://simplifier.net/demis/specimenSTYP)

{{tree:SpecimenSTYP, hybrid}}