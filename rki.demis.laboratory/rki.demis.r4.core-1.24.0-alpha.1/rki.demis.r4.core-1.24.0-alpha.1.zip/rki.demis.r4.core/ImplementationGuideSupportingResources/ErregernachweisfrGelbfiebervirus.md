##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionGFVP](https://simplifier.net/demis/pathogendetectiongfvp)

{{tree:PathogenDetectionGFVP, hybrid}}