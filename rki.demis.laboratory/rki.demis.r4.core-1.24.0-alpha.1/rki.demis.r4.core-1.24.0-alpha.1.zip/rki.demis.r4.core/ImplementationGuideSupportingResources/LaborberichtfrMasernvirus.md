##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMSVP](https://simplifier.net/demis/laboratoryreportmsvp)

{{tree:laboratoryreportmsvp, hybrid}}