##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMBVP](https://simplifier.net/demis/laboratoryreportmbvp)

{{tree:laboratoryreportmbvp, hybrid}}