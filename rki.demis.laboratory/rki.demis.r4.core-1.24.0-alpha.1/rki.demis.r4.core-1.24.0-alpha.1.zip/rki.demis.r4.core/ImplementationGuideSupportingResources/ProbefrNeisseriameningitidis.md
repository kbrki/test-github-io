##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenNEIP](https://simplifier.net/demis/specimenNEIP)

{{tree:SpecimenNEIP, hybrid}}