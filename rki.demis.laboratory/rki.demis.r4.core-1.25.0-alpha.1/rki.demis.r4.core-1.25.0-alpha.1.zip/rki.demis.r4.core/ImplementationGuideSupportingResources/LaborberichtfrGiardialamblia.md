##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportGILP](https://simplifier.net/demis/laboratoryreportgilp)

{{tree:laboratoryreportgilp, hybrid}}
