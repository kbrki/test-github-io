##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCLOP](https://simplifier.net/demis/pathogendetectionclop)

{{tree:PathogenDetectionCLOP, hybrid}} 