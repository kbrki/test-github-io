##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportVCHP](https://simplifier.net/demis/laboratoryreportvchp)

{{tree:laboratoryreportvchp, hybrid}}