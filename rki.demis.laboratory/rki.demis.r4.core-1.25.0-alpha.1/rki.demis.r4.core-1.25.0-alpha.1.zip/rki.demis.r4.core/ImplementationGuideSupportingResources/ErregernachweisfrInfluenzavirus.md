###### Influenzavirus-Erregernachweis

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionINVP](https://simplifier.net/demis/pathogendetectioninvp)

{{tree:PathogenDetectionINVP, hybrid}}
