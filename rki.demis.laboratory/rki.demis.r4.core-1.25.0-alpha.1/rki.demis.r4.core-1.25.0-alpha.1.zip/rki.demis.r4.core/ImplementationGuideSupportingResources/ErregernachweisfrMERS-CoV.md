##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMRSP](https://simplifier.net/demis/pathogendetectionmrsp)

{{tree:PathogenDetectionMRSP, hybrid}} 