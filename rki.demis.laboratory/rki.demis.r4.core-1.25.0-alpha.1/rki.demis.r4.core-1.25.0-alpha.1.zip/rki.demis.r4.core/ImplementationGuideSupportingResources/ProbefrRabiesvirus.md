##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenRBVP](https://simplifier.net/demis/specimenRBVP)

{{tree:SpecimenRBVP, hybrid}}