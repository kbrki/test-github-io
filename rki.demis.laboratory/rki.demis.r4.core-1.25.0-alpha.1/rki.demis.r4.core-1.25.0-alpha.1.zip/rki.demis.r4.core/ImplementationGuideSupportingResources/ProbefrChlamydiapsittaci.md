##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCHLP](https://simplifier.net/demis/specimenCHLP)

{{tree:SpecimenCHLP, hybrid}}