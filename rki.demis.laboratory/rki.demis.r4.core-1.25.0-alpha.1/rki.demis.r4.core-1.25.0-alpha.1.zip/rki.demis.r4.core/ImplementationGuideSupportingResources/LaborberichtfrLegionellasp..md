##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportLEGP](https://simplifier.net/demis/laboratoryreportlegp)

{{tree:laboratoryreportlegp, hybrid}}