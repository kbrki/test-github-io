##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionSPAP](https://simplifier.net/demis/pathogendetectionspap)

{{tree:PathogenDetectionSPAP, hybrid}}