##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionLEGP](https://simplifier.net/demis/pathogendetectionlegp)

{{tree:PathogenDetectionLEGP, hybrid}} 