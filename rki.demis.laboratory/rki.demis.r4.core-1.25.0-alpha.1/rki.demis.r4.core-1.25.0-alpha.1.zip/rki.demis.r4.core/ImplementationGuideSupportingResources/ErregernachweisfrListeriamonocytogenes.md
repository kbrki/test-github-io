##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionLISP](https://simplifier.net/demis/pathogendetectionlisp)

{{tree:PathogenDetectionLISP, hybrid}}