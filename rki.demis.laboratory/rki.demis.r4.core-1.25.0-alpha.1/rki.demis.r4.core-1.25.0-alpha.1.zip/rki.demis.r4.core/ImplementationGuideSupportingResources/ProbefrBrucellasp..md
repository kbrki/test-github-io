##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenBRUP](https://simplifier.net/demis/specimenBRUP)

{{tree:SpecimenBRUP, hybrid}}