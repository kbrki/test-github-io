#### {{page-title}}

[https://demis.rki.de/fhir/ConceptMap/LOINCMaterialToSNOMEDMethod](https://simplifier.net/demis/loincmaterialtosnomedmethod)

Beinhaltet ein Mapping von LOINC-Methoden auf SNOMED-Methoden.

Mit Hilfe der ConceptMap LOINCMaterialToSNOMEDMethod ist abzuleiten, welcher SNOMED-Code in Observation.method anzugeben ist, abhängig von der Nachweismethode des LOINC-Codes, welcher in Observation.code angegeben ist. 

{{tree:loincmaterialtosnomedmethod, hybrid}}