##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMRAP](https://simplifier.net/demis/laboratoryreportmrap)

{{tree:laboratoryreportmrap, hybrid}}