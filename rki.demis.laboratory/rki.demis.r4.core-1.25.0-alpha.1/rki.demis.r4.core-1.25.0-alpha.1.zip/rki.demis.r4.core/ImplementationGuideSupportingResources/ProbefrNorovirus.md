##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenNOVP](https://simplifier.net/demis/specimenNOVP)

{{tree:SpecimenNOVP, hybrid}}