#### Diagnose

[https://demis.rki.de/fhir/StructureDefinition/Diagnose](https://simplifier.net/demis/diagnose-duplicate-5)

Die Diagnose enthält den ICD-10-Code der Diagnose. 

**Hinweis**:  
Übergangsweise können die Befunddaten noch unter Verwendung einer Diagnose und eines Erregernachweises übermittelt werden. 

{{tree:diagnose-duplicate-5, hybrid}}
