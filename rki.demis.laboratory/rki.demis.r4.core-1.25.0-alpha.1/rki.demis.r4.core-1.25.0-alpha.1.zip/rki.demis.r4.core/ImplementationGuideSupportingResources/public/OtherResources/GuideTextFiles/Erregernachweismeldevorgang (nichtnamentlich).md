#### Erregernachweismeldevorgang (nichtnamentlich)

[https://demis.rki.de/fhir/StructureDefinition/NotificationBundleLaboratoryNotByName](https://simplifier.net/demis/notificationbundlelaboratorynotbyname)

Die gesetzlichen Regelungen (§ 7 Abs. 4 IfSG) sehen vor, dass alle Untersuchungsergebnisse auf SARS-CoV-2 (direkter Nachweis mittels Nukleinsäureamplifikationstechnik) nichtnamentlich gemeldet werden sollen.

Der Erregernachweismeldevorgang (nichtnamentlich) ist vom Meldevorgang abgeleitet und bildet den Container für genau eine Erregernachweismeldung (nichtnamentlich).

{{tree:NotificationBundleLaboratoryNotByName, hybrid}}

Beispiel:

{{xml:example-bundle-notificationbundlelaboratorynotbyname-01}}
