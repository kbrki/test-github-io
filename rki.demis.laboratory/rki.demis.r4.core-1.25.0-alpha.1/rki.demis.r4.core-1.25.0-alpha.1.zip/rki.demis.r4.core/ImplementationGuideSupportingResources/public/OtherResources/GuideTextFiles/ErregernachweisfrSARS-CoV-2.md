##### SARS-CoV-2-Erregernachweis

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCVDP](https://simplifier.net/demis/pathogendetectioncvdp)

{{tree:PathogenDetectionCVDP, hybrid}}

Beispiele:

**Nachweis der britischen Variante B.1.1.7 mittels Ganzgenomsequenzierung**

Für den Nachweis einer Variante mittels Sequenzierung ist der LOINC code [96741-4](https://loinc.org/96741-4/) zu verwenden. Varianten sollen als valueString in der PANGOLIN Notation angegeben werden. Die PANGOLIN Notation setzt sich aus einem Buchstaben, gefolgt von maximal drei Zahlen – getrennt durch einen Punkt – zusammen.

{{xml:pathogendetection-b.1.1.7-example}}

**Nachweis der N501Y Mutation**

Für den Nachweis einzelner Mutationen im Spike protein (S Gen) z.B. mittels einer Target-PCR ist der LOINC-Code [96751-3](https://loinc.org/96751-3/) zu verwenden. Mutationen sollen in der Notation entsprechend der Empfehlungen der [Human Genome Variation Society (HGVS)](https://www.hgvs.org/) in einem valueString angegeben werden.

{{xml:pathogendetection-n501y-example}}

**Nachweis der britischen Variante B.1.1.7 mittels Target-PCR**

Um eine Variante mit einer gewissen Wahrscheinlichkeit mittels einzelner Mutationen zu bestimmen, werden eine oder mehrere Target-PCRs durchgeführt. Im valueString werden die ermittelten Mutationen - getrennt durch ein Semikolon - aufgelistet und die wahrscheinliche Variante in PANGOLIN Notation - beginnend mit einem Doppelkreuz - angehängt.

{{xml:pathogendetection-b.1.1.7-example-2}}

**Angabe des CT-Wertes**

**Hinweis**: valueString wie [hier](https://simplifier.net/demis/PathogenDetection-CT-example/~xml) angegeben, KANN NOCH, ABER SOLL ZUKÜNFTIG NICH MEHR VERWENDET WERDEN. Stattdessen soll valueQuantity wie in folgendem Beispiel genutz werden:

```xml
<Observation xmlns="http://hl7.org/fhir">
    <id value="PathogenDetection-CT-example" />
    <meta>
        <profile value="https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCVDP" />
    </meta>
    <status value="final" />
    <category>
        <coding>
            <system value="http://terminology.hl7.org/CodeSystem/observation-category" />
            <code value="laboratory" />
        </coding>
    </category>
    <code>
        <coding>
            <system value="http://loinc.org" />
            <code value="96764-6" />
            <display value="SARS-CoV-2 (COVID-19) E gene [Cycle Threshold #] in Respiratory specimen by NAA with probe detection" />
        </coding>
    </code>
    <subject>
        <reference value="Patient/113de363-be19-46b4-8364-71416c7e662b" />
    </subject>
    <valueQuantity>
        <value value="30" />
        <comparator value="&lt;" />
        <unit value="Cycles" />
        <system value="http://unitsofmeasure.org" />
        <code value="{Ct_value}" />
    </valueQuantity>
    <interpretation>
        <coding>
            <system value="http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation" />
            <code value="POS" />
        </coding>
    </interpretation>
    <specimen>
        <reference value="Specimen/47d61bca-9c53-4422-bb33-3621da084bf4" />
    </specimen>
</Observation>
```


**Angabe der SARS-CoV-2-Virusmenge (Kopien/ml)**
{{xml:pathogendetection-viralload-example}}
