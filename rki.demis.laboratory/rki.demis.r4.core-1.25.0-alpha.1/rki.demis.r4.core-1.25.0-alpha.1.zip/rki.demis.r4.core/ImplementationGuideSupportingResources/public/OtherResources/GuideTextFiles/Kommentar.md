#### Kommentar

https://demis.rki.de/fhir/StructureDefinition/Comment](https://simplifier.net/demis/comment)

Der Kommentar bietet die Möglichkeit zusätzliche Informationen bei Kontaktangaben anzugeben z.B. zur zeitlichen Erreichbarkeit.

{{tree:Comment, hybrid}}

Beispiel:

{{xml:comment-example}}