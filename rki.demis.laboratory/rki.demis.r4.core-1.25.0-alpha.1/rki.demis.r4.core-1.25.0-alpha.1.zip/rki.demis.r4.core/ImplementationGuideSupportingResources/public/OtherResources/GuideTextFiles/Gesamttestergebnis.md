#### Gesamttestergebnis

Über dieses CodeSystem lassen sich die Ergebnisse der Einzeltests in einem Laborberich zusammenfassen. Es wird  angegeben ob der Meldetatbestand erfüllt ist.

{{render:conclusioncode}}