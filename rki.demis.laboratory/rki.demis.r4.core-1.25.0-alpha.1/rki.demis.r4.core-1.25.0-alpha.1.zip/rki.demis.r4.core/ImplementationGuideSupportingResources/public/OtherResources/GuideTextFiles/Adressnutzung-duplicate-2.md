#### Adressnutzung

Über dieses CodeSystem kann die Art der Adresse bzw. des Aufenthaltsortes der Betroffenen Person angegeben werden. 

{{render:addressUse}}