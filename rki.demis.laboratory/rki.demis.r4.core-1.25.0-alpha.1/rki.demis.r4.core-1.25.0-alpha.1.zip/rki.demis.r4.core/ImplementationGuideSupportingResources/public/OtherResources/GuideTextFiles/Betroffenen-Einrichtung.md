##### Betroffenen-Einrichtung

[https://demis.rki.de/fhir/StructureDefinition/NotifiedPersonFacility](https://simplifier.net/demis/notifiedpersonfacility)

Die Betroffenen-Einrichtung beinhaltet die Angaben zu der Einrichtung in der die Betroffene Person untergebracht ist.

{{tree:NotifiedPersonFacility, hybrid}}

Beispiel:

{{xml:notifiedpersonfacility-example}}
