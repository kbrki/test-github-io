##### Erregernachweismeldung (nichtnamentlich)

[https://demis.rki.de/fhir/StructureDefinition/NotificationLaboratoryNotByName](https://simplifier.net/demis/notificationlaboratorynotbyname)

Die Erregernachweismeldung (nichtnamentlich) definiert die Meldeinhalte, die von Laboren in der nichtnamentlichen Meldung gemäß §7 Absatz 4 übermittelt werden müssen.

Zur Übermittlung von Befunddaten soll in der Erregernachweismeldung (nichtnamentlich) der dem Meldetatbestand entsprechende Laborbericht referenziert werden.

{{tree:NotificationLaboratoryNotByName, hybrid}}

Beispiel:
{{xml:example-composition-notificationlaboratorynotbyname-01}}
