#### Einrichtungsart

Über dieses CodeSystem wird die Art einer Einrichtung angegeben.

{{render:organizationType}}