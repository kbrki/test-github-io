#### Anrede

[https://demis.rki.de/fhir/StructureDefinition/Salutation](https://simplifier.net/demis/salutation-duplicate-2)

Für den Melder kann eine Anrede angegeben werden. Diese wird bei Anschreiben verwendet.  
Die Anrede wird in einem Coding-Elements unter Verwendung des ValueSets https://demis.rki.de/fhir/ValueSet/salutation angegeben.

{{tree:salutation-duplicate-2, hybrid}}

Beispiel:

{{xml:salutation-example}}