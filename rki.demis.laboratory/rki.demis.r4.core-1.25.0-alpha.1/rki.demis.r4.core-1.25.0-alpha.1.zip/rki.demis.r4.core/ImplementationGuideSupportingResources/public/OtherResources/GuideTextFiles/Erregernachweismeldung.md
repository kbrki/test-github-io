##### Erregernachweismeldung

[https://demis.rki.de/fhir/StructureDefinition/NotificationLaboratory](https://simplifier.net/demis/notificationlaboratory)

Die Erregernachweismeldung definiert die Meldeinhalte, die von Laboren übermittelt werden müssen.

Zur Übermittlung von Befunddaten soll in der Erregernachweismeldung der dem Meldetatbestand entsprechende Laborbericht referenziert werden.
Z.B. sollen SARS-CoV-2-Befunddaten in einem SARS-CoV-2-Laborbericht (DiagnosticReportCVDP) in der Erregernachweismeldung übermittelt werden, siehe Beispiel. 

{{tree:NotificationLaboratory, hybrid}}

Beispiel: 
{{xml:notificationlaboratorycvdp-example}}
