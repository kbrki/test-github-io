##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportWNVP](https://simplifier.net/demis/laboratoryreportwnvp)

{{tree:laboratoryreportwnvp, hybrid}}