##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMPXP](https://simplifier.net/demis/laboratoryreportmpxp)

{{tree:laboratoryreportmpxp, hybrid}}
