##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCORP](https://simplifier.net/demis/specimenCORP)

{{tree:SpecimenCORP, hybrid}}