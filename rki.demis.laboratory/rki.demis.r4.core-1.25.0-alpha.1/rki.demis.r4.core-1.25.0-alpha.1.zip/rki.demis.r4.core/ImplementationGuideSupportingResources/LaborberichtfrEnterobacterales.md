##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportEBCP](https://simplifier.net/demis/laboratoryreportebcp)

{{tree:laboratoryreportebcp, hybrid}}