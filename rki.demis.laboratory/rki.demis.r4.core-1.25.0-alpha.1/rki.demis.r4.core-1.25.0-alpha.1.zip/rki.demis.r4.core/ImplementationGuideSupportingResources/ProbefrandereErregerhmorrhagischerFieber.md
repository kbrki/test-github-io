##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCKVP](https://simplifier.net/demis/specimenCKVP)

{{tree:SpecimenCKVP, hybrid}}