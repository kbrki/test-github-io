##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportLEPP](https://simplifier.net/demis/laboratoryreportlepp)

{{tree:laboratoryreportlepp, hybrid}}