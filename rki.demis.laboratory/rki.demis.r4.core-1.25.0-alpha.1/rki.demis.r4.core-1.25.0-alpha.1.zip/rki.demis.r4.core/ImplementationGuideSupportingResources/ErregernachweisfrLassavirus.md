##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionLSVP](https://simplifier.net/demis/pathogendetectionlsvp)

{{tree:PathogenDetectionLSVP, hybrid}}