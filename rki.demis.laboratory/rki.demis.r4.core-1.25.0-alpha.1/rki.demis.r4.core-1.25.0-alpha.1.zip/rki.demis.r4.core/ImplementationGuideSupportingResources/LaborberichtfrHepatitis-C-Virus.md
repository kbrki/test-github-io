##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHCVP](https://simplifier.net/demis/laboratoryreporthcvp)

{{tree:laboratoryreporthcvp, hybrid}}