##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHEVP](https://simplifier.net/demis/pathogendetectionhevp)

{{tree:PathogenDetectionHEVP, hybrid}}