##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenLEPP](https://simplifier.net/demis/specimenLEPP)

{{tree:SpecimenLEPP, hybrid}}