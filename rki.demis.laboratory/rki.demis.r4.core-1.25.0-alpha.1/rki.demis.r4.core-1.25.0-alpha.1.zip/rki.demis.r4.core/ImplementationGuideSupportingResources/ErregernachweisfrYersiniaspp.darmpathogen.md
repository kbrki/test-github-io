##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionYENP](https://simplifier.net/demis/pathogendetectionyenp)

{{tree:PathogenDetectionYENP, hybrid}}