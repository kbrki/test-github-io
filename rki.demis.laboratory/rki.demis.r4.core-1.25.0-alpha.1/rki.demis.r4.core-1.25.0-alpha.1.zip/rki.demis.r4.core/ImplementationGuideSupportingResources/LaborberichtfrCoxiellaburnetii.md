##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCOXP](https://simplifier.net/demis/laboratoryreportcoxp)

{{tree:laboratoryreportcoxp, hybrid}}