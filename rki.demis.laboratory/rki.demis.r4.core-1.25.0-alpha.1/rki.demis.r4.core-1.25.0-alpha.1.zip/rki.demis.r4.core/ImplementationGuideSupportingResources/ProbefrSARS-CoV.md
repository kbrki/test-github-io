##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenCVSP](https://simplifier.net/demis/specimenCVSP)

{{tree:SpecimenCVSP, hybrid}}