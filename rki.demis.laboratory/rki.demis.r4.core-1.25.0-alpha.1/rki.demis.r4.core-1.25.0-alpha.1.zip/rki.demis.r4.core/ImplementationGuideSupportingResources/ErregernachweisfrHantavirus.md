##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHTVP](https://simplifier.net/demis/pathogendetectionhtvpp)

{{tree:PathogenDetectionHTVP, hybrid}}