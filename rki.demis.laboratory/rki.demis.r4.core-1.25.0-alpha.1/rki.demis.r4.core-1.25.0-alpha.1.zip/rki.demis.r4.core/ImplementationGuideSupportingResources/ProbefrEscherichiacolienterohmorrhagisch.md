##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenEHCP](https://simplifier.net/demis/specimenEHCP)

{{tree:SpecimenEHCP, hybrid}}