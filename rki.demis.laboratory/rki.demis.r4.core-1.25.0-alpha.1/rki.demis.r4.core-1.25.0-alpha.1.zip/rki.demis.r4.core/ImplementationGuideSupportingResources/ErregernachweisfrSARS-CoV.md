##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCVSP](https://simplifier.net/demis/pathogendetectioncvsp)

{{tree:PathogenDetectionCVSP, hybrid}} 