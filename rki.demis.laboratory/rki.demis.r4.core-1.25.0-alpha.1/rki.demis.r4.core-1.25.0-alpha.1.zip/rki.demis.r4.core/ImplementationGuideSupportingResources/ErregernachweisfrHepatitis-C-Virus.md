##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHCVP](https://simplifier.net/demis/pathogendetectionhcvp)

{{tree:PathogenDetectionHCVP, hybrid}} 