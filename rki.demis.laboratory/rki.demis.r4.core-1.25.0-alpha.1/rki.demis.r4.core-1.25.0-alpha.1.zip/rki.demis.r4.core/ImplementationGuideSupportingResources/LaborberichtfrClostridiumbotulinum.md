##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCLOP](https://simplifier.net/demis/laboratoryreportclop)

{{tree:laboratoryreportclop, hybrid}}
