##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMYTP](https://simplifier.net/demis/specimenMYTP)

{{tree:SpecimenMYTP, hybrid}}