##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenFSVP](https://simplifier.net/demis/specimenFSVP)

{{tree:SpecimenFSVP, hybrid}}