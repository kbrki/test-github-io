##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportOPXP](https://simplifier.net/demis/laboratoryreportopxp)

{{tree:laboratoryreportopxp, hybrid}}
