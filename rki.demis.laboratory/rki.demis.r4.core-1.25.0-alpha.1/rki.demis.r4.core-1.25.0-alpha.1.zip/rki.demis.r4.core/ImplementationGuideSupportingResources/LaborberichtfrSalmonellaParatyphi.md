##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportSPAP](https://simplifier.net/demis/laboratoryreportspap)

{{tree:laboratoryreportspap, hybrid}}