##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMPXP](https://simplifier.net/demis/specimenMPXP)

{{tree:SpecimenMPXP, hybrid}}
