##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionSALP](https://simplifier.net/demis/pathogendetectionsalp)

{{tree:PathogenDetectionSALP, hybrid}}