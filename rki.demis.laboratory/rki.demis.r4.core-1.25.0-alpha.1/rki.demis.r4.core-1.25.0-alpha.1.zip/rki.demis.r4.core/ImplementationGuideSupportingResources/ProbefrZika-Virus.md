##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenZKVP](https://simplifier.net/demis/specimenZKVP)

{{tree:SpecimenZKVP, hybrid}}