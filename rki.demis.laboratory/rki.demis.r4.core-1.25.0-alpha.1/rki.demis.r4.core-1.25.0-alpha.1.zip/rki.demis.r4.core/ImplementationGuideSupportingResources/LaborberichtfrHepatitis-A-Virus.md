##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHAVP](https://simplifier.net/demis/laboratoryreporthavp)

{{tree:laboratoryreporthavp, hybrid}}