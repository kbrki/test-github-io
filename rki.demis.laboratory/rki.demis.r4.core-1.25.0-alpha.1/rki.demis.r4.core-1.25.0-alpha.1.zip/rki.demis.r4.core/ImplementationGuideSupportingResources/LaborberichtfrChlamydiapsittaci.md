##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCHLP](https://simplifier.net/demis/laboratoryreportchlp)

{{tree:laboratoryreportchlp, hybrid}}