##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportNEIP](https://simplifier.net/demis/laboratoryreportneip)

{{tree:laboratoryreportneip, hybrid}}