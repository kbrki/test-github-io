##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionADVP](https://simplifier.net/demis/pathogendetectionadvp)

{{tree:PathogenDetectionADVP, hybrid}} 