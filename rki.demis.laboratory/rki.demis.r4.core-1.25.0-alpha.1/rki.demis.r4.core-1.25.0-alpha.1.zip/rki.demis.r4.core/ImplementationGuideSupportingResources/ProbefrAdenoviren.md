##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenADVP](https://simplifier.net/demis/specimenADVP)

{{tree:https://demis.rki.de/fhir/StructureDefinition/SpecimenADVP, hybrid}}