##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionRBVP](https://simplifier.net/demis/pathogendetectionrbvp)

{{tree:PathogenDetectionRBVP, hybrid}}