##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenECOP](https://simplifier.net/demis/specimenECOP)

{{tree:SpecimenECOP, hybrid}}