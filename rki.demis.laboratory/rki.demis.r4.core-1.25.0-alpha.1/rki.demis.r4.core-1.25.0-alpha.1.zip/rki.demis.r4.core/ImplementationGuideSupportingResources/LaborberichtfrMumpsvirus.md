##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMPVP](https://simplifier.net/demis/laboratoryreportmpvp)

{{tree:laboratoryreportmpvp, hybrid}}