##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMYLP](https://simplifier.net/demis/laboratoryreportmylp)

{{tree:laboratoryreportmylp, hybrid}}