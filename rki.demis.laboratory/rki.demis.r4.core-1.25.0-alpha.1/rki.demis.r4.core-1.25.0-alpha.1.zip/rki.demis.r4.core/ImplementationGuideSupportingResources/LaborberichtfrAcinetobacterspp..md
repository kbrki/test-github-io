###### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportACBP](https://simplifier.net/demis/laboratoryreportacbp)

{{tree:laboratoryreportacbp, hybrid}}