#### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/TransmittingSite](https://simplifier.net/demis/transmittingsite)


{{tree:TransmittingSite, hybrid}}