##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenBOVP](https://simplifier.net/demis/specimenBOVP)

{{tree:SpecimenBOVP, hybrid}}