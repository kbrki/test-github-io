##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMSVP](https://simplifier.net/demis/specimenMSVP)

{{tree:SpecimenMSVP, hybrid}}