##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionFRTP](https://simplifier.net/demis/pathogendetectionfrtp)

{{tree:PathogenDetectionFRTP, hybrid}}