##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHDVP](https://simplifier.net/demis/pathogendetectionhdvp)

{{tree:PathogenDetectionEBVP, hybrid}} 