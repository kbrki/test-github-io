##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMBVP](https://simplifier.net/demis/pathogendetectionmbvp)

{{tree:PathogenDetectionMBVP, hybrid}}