##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenSHIP](https://simplifier.net/demis/specimenSHIP)

{{tree:SpecimenSHIP, hybrid}}