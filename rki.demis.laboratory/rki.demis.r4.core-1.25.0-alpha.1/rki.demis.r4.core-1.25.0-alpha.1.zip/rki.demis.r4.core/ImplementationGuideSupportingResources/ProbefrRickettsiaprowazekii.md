##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenRICP](https://simplifier.net/demis/specimenRICP)

{{tree:SpecimenRICP, hybrid}}