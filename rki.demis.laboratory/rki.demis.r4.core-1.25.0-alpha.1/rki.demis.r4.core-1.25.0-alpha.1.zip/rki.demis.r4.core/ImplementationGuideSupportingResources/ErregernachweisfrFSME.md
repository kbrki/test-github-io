##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionFSVP](https://simplifier.net/demis/pathogendetectionfsvp)

{{tree:PathogenDetectionFSVP, hybrid}}