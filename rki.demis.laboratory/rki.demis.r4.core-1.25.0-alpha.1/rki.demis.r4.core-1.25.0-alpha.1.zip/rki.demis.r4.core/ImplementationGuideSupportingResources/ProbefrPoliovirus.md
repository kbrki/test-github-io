##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenPOVP](https://simplifier.net/demis/specimenPOVP)

{{tree:SpecimenPOVP, hybrid}}