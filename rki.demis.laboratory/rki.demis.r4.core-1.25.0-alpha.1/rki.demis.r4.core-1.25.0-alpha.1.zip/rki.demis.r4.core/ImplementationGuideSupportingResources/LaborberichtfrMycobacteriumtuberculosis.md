##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportMYTP](https://simplifier.net/demis/laboratoryreportmytp)

{{tree:laboratoryreportmytp, hybrid}}