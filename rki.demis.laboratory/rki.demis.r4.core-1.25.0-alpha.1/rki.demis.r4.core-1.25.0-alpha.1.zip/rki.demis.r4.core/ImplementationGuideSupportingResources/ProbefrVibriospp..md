##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenVCHP](https://simplifier.net/demis/specimenVCHP)

{{tree:SpecimenVCHP, hybrid}}