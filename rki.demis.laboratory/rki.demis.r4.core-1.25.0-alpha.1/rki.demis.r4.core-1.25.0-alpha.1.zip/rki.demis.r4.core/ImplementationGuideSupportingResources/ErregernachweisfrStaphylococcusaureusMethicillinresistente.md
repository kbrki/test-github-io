##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionmrap](https://simplifier.net/demis/pathogendetectionMRAP)

{{tree:PathogenDetectionMRAP, hybrid}}