##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionBANP](https://simplifier.net/demis/pathogendetectionbanp)

{{tree:PathogenDetectionBANP, hybrid}}