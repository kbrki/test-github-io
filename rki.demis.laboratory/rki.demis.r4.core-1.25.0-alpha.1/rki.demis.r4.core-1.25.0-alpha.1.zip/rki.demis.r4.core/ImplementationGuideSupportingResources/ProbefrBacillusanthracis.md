##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenBANP](https://simplifier.net/demis/specimenBANP)

{{tree:SpecimenBANP, hybrid}}