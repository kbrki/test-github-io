##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenYENP](https://simplifier.net/demis/specimenYENP)

{{tree:SpecimenYENP, hybrid}}