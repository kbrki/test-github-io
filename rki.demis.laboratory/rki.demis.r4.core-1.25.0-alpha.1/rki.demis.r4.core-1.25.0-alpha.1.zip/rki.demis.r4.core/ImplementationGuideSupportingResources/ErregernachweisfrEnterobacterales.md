##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionEBCP](https://simplifier.net/demis/pathogendetectionebcp)

{{tree:PathogenDetectionEBCP, hybrid}} 