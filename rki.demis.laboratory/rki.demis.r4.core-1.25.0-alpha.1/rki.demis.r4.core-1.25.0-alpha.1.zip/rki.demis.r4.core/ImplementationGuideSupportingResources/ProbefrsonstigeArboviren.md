##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenABVP](https://simplifier.net/demis/specimenABVP)

{{tree:SpecimenABVP, hybrid}}