##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportYENP](https://simplifier.net/demis/laboratoryreportyenp)

{{tree:laboratoryreportyenp, hybrid}}