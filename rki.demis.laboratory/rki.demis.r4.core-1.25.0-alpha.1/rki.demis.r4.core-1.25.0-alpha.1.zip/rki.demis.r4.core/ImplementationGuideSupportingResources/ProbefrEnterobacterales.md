##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenEBCP](https://simplifier.net/demis/specimenEBCP)

{{tree:SpecimenEBCP, hybrid}}