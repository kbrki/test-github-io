##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHINP](https://simplifier.net/demis/pathogendetectionhinp)

{{tree:PathogenDetectionHINP, hybrid}}