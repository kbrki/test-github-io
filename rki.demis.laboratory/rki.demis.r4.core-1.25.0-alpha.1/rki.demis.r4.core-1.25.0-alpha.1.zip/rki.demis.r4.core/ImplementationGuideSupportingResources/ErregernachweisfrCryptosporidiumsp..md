##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionCRYP](https://simplifier.net/demis/pathogendetectioncrypp)

{{tree:PathogenDetectionCRYP, hybrid}} 