##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportADVP](https://simplifier.net/demis/laboratoryreportadvp)

{{tree:laboratoryreportadvp, hybrid}}