##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionMYLP](https://simplifier.net/demis/pathogendetectionmylp)

{{tree:PathogenDetectionMYLP, hybrid}} 