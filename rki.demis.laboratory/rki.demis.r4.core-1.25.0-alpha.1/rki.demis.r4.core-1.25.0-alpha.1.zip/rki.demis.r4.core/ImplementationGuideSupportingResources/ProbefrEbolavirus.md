##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenEBVP](https://simplifier.net/demis/specimenEBVP)

{{tree:SpecimenEBVP, hybrid}}