##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionSHIP](https://simplifier.net/demis/pathogendetectionship)

{{tree:PathogenDetectionSHIP, hybrid}}