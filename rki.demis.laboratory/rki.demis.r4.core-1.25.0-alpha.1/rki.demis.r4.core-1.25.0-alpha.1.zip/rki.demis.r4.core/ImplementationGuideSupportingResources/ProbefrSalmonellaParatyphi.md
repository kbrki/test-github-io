##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenSPAP](https://simplifier.net/demis/specimenSPAP)

{{tree:SpecimenSPAP, hybrid}}