##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHBVP](https://simplifier.net/demis/specimenHBVP)

{{tree:SpecimenHBVP, hybrid}}