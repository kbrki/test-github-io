##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenWNVP](https://simplifier.net/demis/specimenWNVP)

{{tree:SpecimenWNVP, hybrid}}