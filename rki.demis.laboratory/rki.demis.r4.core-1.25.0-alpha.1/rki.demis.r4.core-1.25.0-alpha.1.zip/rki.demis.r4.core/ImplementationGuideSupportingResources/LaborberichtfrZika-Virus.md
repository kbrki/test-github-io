##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportZKVP](https://simplifier.net/demis/laboratoryreportzkvp)

{{tree:laboratoryreportzkvp, hybrid}}