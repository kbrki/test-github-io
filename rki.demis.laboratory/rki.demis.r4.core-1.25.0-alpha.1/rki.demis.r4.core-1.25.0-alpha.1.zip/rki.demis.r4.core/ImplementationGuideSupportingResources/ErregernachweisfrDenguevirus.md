##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionDENP](https://simplifier.net/demis/pathogendetectiondenp)

{{tree:PathogenDetectionDENP, hybrid}}