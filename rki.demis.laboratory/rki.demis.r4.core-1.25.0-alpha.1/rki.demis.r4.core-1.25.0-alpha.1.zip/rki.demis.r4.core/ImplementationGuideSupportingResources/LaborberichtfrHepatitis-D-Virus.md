##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHDVP](https://simplifier.net/demis/laboratoryreporthdvp)

{{tree:laboratoryreporthdvp, hybrid}}