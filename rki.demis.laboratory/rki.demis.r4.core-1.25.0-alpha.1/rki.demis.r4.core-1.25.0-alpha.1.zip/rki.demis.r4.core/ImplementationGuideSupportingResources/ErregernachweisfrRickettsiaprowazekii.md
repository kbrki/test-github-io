##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionRICP](https://simplifier.net/demis/pathogendetectionricp)

{{tree:PathogenDetectionRICP, hybrid}} 