##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportBORP](https://simplifier.net/demis/laboratoryreportborp)

{{tree:laboratoryreportborp, hybrid}}