##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenMRAP](https://simplifier.net/demis/specimenMRAP)

{{tree:SpecimenMRAP, hybrid}}