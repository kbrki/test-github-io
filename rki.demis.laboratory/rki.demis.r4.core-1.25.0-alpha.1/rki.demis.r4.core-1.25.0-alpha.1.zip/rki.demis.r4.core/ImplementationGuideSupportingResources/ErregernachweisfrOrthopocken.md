###### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionOPXP](https://simplifier.net/demis/pathogendetectionopxp)

{{tree:PathogenDetectionOPXP, hybrid}}
