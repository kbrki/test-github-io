##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionBRUP](https://simplifier.net/demis/pathogendetectionbrup)

{{tree:PathogenDetectionBRUP, hybrid}}