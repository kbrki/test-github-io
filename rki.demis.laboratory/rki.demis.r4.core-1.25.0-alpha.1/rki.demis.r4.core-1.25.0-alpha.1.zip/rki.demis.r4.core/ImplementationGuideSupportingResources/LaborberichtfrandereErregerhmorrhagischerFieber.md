##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHFAP](https://simplifier.net/demis/laboratoryreporthfap)

{{tree:laboratoryreporthfap, hybrid}}