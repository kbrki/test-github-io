##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCVSP](https://simplifier.net/demis/laboratoryreportcvsp)

{{tree:laboratoryreportcvsp, hybrid}}