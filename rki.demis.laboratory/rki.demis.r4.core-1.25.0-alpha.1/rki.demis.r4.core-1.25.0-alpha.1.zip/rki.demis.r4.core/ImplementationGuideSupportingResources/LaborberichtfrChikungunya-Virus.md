##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCKVP](https://simplifier.net/demis/laboratoryreportckvp)

{{tree:laboratoryreportckvp, hybrid}}