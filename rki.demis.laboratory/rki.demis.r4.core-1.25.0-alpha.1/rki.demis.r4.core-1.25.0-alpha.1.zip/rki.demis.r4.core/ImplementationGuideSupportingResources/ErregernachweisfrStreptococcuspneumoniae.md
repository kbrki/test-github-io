##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionSPNP](https://simplifier.net/demis/pathogendetectionspnp)

{{tree:PathogenDetectionSPNP, hybrid}} 