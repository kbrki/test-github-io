##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportHINP](https://simplifier.net/demis/laboratoryreporthinp)

{{tree:laboratoryreporthinp, hybrid}}