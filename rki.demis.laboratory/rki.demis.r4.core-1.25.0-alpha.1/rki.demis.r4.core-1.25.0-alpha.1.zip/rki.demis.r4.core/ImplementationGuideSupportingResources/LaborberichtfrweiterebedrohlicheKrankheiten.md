##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportWBKP](https://simplifier.net/demis/laboratoryreportwbkp)

{{tree:laboratoryreportwbkp, hybrid}}