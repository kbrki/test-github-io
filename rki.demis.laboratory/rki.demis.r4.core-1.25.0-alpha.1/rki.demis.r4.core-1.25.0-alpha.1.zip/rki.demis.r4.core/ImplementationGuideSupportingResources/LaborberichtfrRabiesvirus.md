##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportRBVP](https://simplifier.net/demis/laboratoryreportrbvp)

{{tree:laboratoryreportrbvp, hybrid}}