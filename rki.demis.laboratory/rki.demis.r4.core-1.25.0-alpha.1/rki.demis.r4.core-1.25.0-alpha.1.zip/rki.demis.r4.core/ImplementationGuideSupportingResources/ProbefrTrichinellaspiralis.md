##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenTRIP](https://simplifier.net/demis/specimenTRIP)

{{tree:SpecimenTRIP, hybrid}}