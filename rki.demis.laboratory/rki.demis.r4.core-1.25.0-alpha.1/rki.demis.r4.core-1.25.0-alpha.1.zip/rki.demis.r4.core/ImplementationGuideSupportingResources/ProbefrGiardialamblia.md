##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenGILP](https://simplifier.net/demis/specimenGILP)

{{tree:SpecimenGILP, hybrid}}