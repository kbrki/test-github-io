##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenHCVP](https://simplifier.net/demis/specimenHCVP)

{{tree:SpecimenHCVP, hybrid}}