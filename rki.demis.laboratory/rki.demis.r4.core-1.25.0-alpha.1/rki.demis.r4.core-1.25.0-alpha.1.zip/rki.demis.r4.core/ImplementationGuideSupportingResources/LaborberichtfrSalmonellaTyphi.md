##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportSTYP](https://simplifier.net/demis/laboratoryreportstyp)

{{tree:laboratoryreportstyp, hybrid}}