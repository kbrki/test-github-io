##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportSHIP](https://simplifier.net/demis/laboratoryreportship)

{{tree:laboratoryreportship, hybrid}}