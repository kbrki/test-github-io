##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportCORP](https://simplifier.net/demis/laboratoryreportcorp)

{{tree:laboratoryreportcorp, hybrid}}