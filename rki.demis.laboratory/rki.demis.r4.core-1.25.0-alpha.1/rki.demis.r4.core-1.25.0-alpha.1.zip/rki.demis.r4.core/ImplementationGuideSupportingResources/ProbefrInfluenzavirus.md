##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/SpecimenINVP](https://simplifier.net/demis/specimenINVP)

{{tree:SpecimenINVP, hybrid}}