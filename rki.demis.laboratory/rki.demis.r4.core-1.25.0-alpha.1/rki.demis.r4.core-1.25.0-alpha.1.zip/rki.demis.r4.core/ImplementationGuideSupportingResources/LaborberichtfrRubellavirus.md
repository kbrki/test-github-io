##### {{page-title}}


[https://demis.rki.de/fhir/StructureDefinition/LaboratoryReportRUVP](https://simplifier.net/demis/laboratoryreportruvp)

{{tree:laboratoryreportruvp, hybrid}}