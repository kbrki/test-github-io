##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionHAVP](https://simplifier.net/demis/pathogendetectionhavp)

{{tree:PathogenDetectionHAVP, hybrid}}