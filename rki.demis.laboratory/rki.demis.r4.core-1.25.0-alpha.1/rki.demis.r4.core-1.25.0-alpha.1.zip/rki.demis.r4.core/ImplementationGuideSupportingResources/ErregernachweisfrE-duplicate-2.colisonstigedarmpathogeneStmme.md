##### {{page-title}}

[https://demis.rki.de/fhir/StructureDefinition/PathogenDetectionECOP](https://simplifier.net/demis/pathogendetectionecop)

{{tree:PathogenDetectionECOP, hybrid}}